<?php
require_once '../config/db.php';

$username = 'admin';
$password = 'admin123';           // Change this after first login!
$firstName = 'System';
$lastName = 'Administrator';

$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("
    INSERT INTO users (Username, PasswordHash, Role, FirstName, LastName, Email) 
    VALUES (?, ?, 'admin', ?, ?, ?)
    ON DUPLICATE KEY UPDATE PasswordHash = VALUES(PasswordHash)
");

$stmt->execute([$username, $hash, $firstName, $lastName, 'admin@school.edu']);

echo "<h2>✅ Setup Complete!</h2>";
echo "<p>Admin Username: <strong>admin</strong></p>";
echo "<p>Password: <strong>admin123</strong></p>";
echo "<p><a href='login.php'>Go to Login</a></p>";
?>