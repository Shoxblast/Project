<?php 
require_once '../config/db.php';
require_once '../includes/session.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstName     = trim($_POST['first_name'] ?? '');
    $lastName      = trim($_POST['last_name'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $phone         = trim($_POST['phone'] ?? '');
    $dateOfBirth   = $_POST['date_of_birth'] ?? '';
    $gender        = $_POST['gender'] ?? '';
    $ethnicity     = trim($_POST['ethnicity'] ?? '');
    $religion      = trim($_POST['religion'] ?? '');
    $region        = trim($_POST['region'] ?? '');
    $city          = trim($_POST['city'] ?? '');
    $zipcode       = trim($_POST['zipcode'] ?? '');
    $dialect       = trim($_POST['dialect'] ?? '');
    $guardianName  = trim($_POST['guardian_name'] ?? '');
    $guardianPhone = trim($_POST['guardian_phone'] ?? '');
    $guardianEmail = trim($_POST['guardian_email'] ?? '');
    $courseID      = (int)($_POST['course_id'] ?? 0);

    if (empty($firstName) || empty($lastName) || empty($email) || empty($courseID)) {
        $_SESSION['error'] = "Please fill all required fields.";
        header("Location: register_student.php");
        exit();
    }

    $year = date('Y');
    $stmt = $pdo->prepare("SELECT MAX(StudentNumber) as last FROM students WHERE StudentNumber LIKE ?");
    $stmt->execute(["$year-%"]);
    $last = $stmt->fetchColumn();
    $nextNum = ($last) ? (int)substr($last, 5) + 1 : 1;
    $studentNumber = $year . '-' . str_pad($nextNum, 4, '0', STR_PAD_LEFT);

    $passwordHash = password_hash('password123', PASSWORD_DEFAULT);

    try {
        $pdo->beginTransaction();

        $deptStmt = $pdo->prepare("SELECT DepartmentID FROM courses WHERE CourseID = ?");
        $deptStmt->execute([$courseID]);
        $departmentID = $deptStmt->fetchColumn() ?: null;

        $stmt = $pdo->prepare("
            INSERT INTO users (Username, PasswordHash, Role, FirstName, LastName, Email, Phone, DepartmentID) 
            VALUES (?, ?, 'student', ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$studentNumber, $passwordHash, $firstName, $lastName, $email, $phone, $departmentID]);
        $userID = $pdo->lastInsertId();

        $stmt2 = $pdo->prepare("
            INSERT INTO students 
            (UserID, StudentNumber, DateOfBirth, Gender, Ethnicity, Religion, Region, City, ZipCode, Dialect, 
             GuardianName, GuardianPhone, GuardianEmail, Status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')
        ");
        $stmt2->execute([$userID, $studentNumber, $dateOfBirth, $gender, $ethnicity, $religion, 
                        $region, $city, $zipcode, $dialect, $guardianName, $guardianPhone, $guardianEmail]);

        $pdo->prepare("INSERT INTO student_accounts (StudentID, TotalBalance) VALUES (LAST_INSERT_ID(), 0)")->execute();

        $pdo->commit();

        $_SESSION['success'] = "✅ Registration Successful!<br>
                                <strong>Student Number:</strong> $studentNumber<br>
                                <strong>Default Password:</strong> password123";
        header("Location: register_student.php");
        exit();

    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "❌ Registration failed: " . $e->getMessage();
    }
}
?>

<?php 
require_once '../includes/header.php'; 
$page_title = "New Student Registration";
?>

<div style="max-width: 900px; margin: 30px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.1);">

    <h2>🎓 New Student Registration</h2>
    <?php displayMessage(); ?>

    <form method="POST">
        <h3>Personal Information</h3>
        <input type="text" name="first_name" placeholder="First Name" required>
        <input type="text" name="last_name" placeholder="Last Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="phone" placeholder="Phone Number" required>
        <input type="date" name="date_of_birth" required>
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select>

        <h3>Course / Program</h3>
        <select name="course_id" required>
            <option value="">-- Select Course --</option>
            <?php
            $courses = $pdo->query("
                SELECT c.CourseID, c.CourseCode, c.CourseName, d.DepartmentAcronym 
                FROM courses c 
                JOIN departments d ON c.DepartmentID = d.DepartmentID 
                ORDER BY d.DepartmentName, c.CourseCode
            ")->fetchAll();
            foreach ($courses as $c):
            ?>
                <option value="<?= $c['CourseID'] ?>">
                    <?= htmlspecialchars($c['CourseCode']) ?> - <?= htmlspecialchars($c['CourseName']) ?> (<?= $c['DepartmentAcronym'] ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <h3>Address Information</h3>
        <select name="region" id="region" onchange="loadProvinces(this.value)" required>
            <option value="">-- Select Region --</option>
            <?php
            $regions = $pdo->query("SELECT DISTINCT TRIM(REGION) as r FROM cities ORDER BY r")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($regions as $r) echo "<option value='".htmlspecialchars($r)."'>".htmlspecialchars($r)."</option>";
            ?>
        </select>

        <select name="city" id="city" onchange="getZipCode(this.value)" required>
            <option value="">-- Select City/Municipality --</option>
        </select>

        <input type="text" name="zipcode" id="zipcode" placeholder="Zip Code" readonly required>

        <h3>Other Information</h3>
        <select name="ethnicity" required>
            <option value="">Select Ethnicity</option>
            <?php
            $eth = $pdo->query("SELECT DISTINCT ethnicname FROM ethnicity ORDER BY ethnicname")->fetchAll();
            foreach ($eth as $e) {
                $val = trim($e['ethnicname']);
                if ($val) echo "<option value='".htmlspecialchars($val)."'>".htmlspecialchars($val)."</option>";
            }
            ?>
        </select>

        <select name="religion" required>
            <option value="">Select Religion</option>
            <?php
            $rel = $pdo->query("SELECT DISTINCT religion FROM religions ORDER BY religion")->fetchAll();
            foreach ($rel as $r) {
                $val = trim($r['religion']);
                if ($val) echo "<option value='".htmlspecialchars($val)."'>".htmlspecialchars($val)."</option>";
            }
            ?>
        </select>

        <select name="dialect" required>
            <option value="">Select Dialect</option>
            <?php
            $dia = $pdo->query("SELECT DISTINCT dialects FROM dialects ORDER BY dialects")->fetchAll();
            foreach ($dia as $d) {
                $val = trim($d['dialects']);
                if ($val) echo "<option value='".htmlspecialchars($val)."'>".htmlspecialchars($val)."</option>";
            }
            ?>
        </select>

        <h3>Guardian Information</h3>
        <input type="text" name="guardian_name" placeholder="Guardian Full Name" required>
        <input type="text" name="guardian_phone" placeholder="Guardian Phone Number" required>
        <input type="email" name="guardian_email" placeholder="Guardian Email (Optional)">

        <br><br>
        <button type="submit" style="width:100%; padding:16px; font-size:18px; background:#1e40af; color:white; border:none; border-radius:8px;">
            Complete Registration
        </button>
    </form>
</div>

<script>
// Dynamic Province & City
function loadProvinces(region) {
    if (!region) return;
    fetch(`get_provinces.php?region=${encodeURIComponent(region)}`)
        .then(r => r.json())
        .then(data => {
            const sel = document.getElementById('city');
            sel.innerHTML = '<option value="">-- Select City/Municipality --</option>';
            data.forEach(p => sel.innerHTML += `<option value="${p}">${p}</option>`);
        });
}

function getZipCode(city) {
    if (!city) return;
    fetch(`get_zipcode.php?city=${encodeURIComponent(city)}`)
        .then(r => r.json())
        .then(data => {
            document.getElementById('zipcode').value = data.zipcode || '';
        });
}
</script>

<?php include '../includes/footer.php'; ?>