<?php
require_once '../config/db.php';
require_once '../includes/session.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND IsActive = 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['PasswordHash'])) {
        $_SESSION['user_id']   = $user['UserID'];
        $_SESSION['username']  = $user['Username'];
        $_SESSION['role']      = $user['Role'];
        $_SESSION['fullname']  = $user['FirstName'] . " " . $user['LastName'];
        $_SESSION['department_id'] = $user['DepartmentID'];

        // Redirect based on role
        if ($user['Role'] === 'dean') {
            header("Location: ../dean/dashboard.php");
        } elseif ($user['Role'] === 'faculty') {
            header("Location: ../faculty/dashboard.php");
        } else {
            header("Location: ../index.php");
        }
        exit();
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - School System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h2>Login</h2>
    <?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>