<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/header.php';   // ← Use new global header

$page_title = "Register New Staff Member";

// Temporarily open for initial setup
// requireAdmin();  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username   = trim($_POST['username']);
    $password   = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $firstName  = trim($_POST['first_name']);
    $lastName   = trim($_POST['last_name']);
    $email      = trim($_POST['email']);
    $phone      = trim($_POST['phone']);
    $role       = $_POST['role'];
    $departmentID = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    $position   = trim($_POST['position'] ?? '');

    try {
        $stmt = $pdo->prepare("
            INSERT INTO users (Username, PasswordHash, Role, FirstName, LastName, Email, Phone, DepartmentID) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        if ($stmt->execute([$username, $password, $role, $firstName, $lastName, $email, $phone, $departmentID])) {
            $newUserID = $pdo->lastInsertId();

            if ($role === 'faculty') {
                $pdo->prepare("INSERT INTO faculty (UserID, Position) VALUES (?, ?)")->execute([$newUserID, $position]);
            }

            $_SESSION['success'] = "✅ Staff member ($role) registered successfully!<br>Default password can be changed later.";
            header("Location: register_staff.php");
            exit();
        }
    } catch (Exception $e) {
        $_SESSION['error'] = "Registration failed. Username or Email may already exist.";
    }
}
?>

<div style="min-height: 70vh;">

<h2>👤 Register New Staff Member</h2>
<?php displayMessage(); ?>

<p><strong>Note:</strong> Registration is open for initial setup.</p>

<form method="POST" style="max-width: 780px;">

    <h3>Basic Information</h3>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 18px;">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 18px;">
        <input type="text" name="first_name" placeholder="First Name" required>
        <input type="text" name="last_name" placeholder="Last Name" required>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 18px;">
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="phone" placeholder="Phone Number">
    </div>

    <h3>Role & Assignment</h3>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-bottom: 25px;">
        <select name="role" required onchange="toggleFacultyFields(this)">
            <option value="">Select Role</option>
            <option value="admin">Admin</option>
            <option value="dean">Dean</option>
            <option value="faculty">Faculty / Teacher</option>
            <option value="finance">Finance</option>
            <option value="cashier">Cashier</option>
        </select>

        <select name="department_id">
            <option value="">No Department / School-wide</option>
            <?php
            $depts = $pdo->query("SELECT * FROM departments ORDER BY DepartmentName")->fetchAll();
            foreach ($depts as $d) {
                echo "<option value='{$d['DepartmentID']}'>{$d['DepartmentName']} ({$d['DepartmentAcronym']})</option>";
            }
            ?>
        </select>
    </div>

    <div id="faculty_fields" style="display:none; margin-bottom: 25px;">
        <input type="text" name="position" placeholder="Position (e.g. Professor, Instructor)" style="width:100%;">
    </div>

    <button type="submit" style="padding: 16px; font-size: 17px; width: 100%; background: #1e40af; color: white; border: none; border-radius: 8px;">
        Register Staff Member
    </button>
</form>

</div>

<script>
function toggleFacultyFields(select) {
    document.getElementById('faculty_fields').style.display = 
        select.value === 'faculty' ? 'block' : 'none';
}
</script>

<?php include '../includes/footer.php'; ?>