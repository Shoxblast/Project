<?php
require_once '../config/db.php';
require_once '../includes/session.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = 'student' AND IsActive = 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['PasswordHash'])) {
        $_SESSION['user_id'] = $user['UserID'];
        $_SESSION['role'] = 'student';
        $_SESSION['fullname'] = $user['FirstName'] . " " . $user['LastName'];

        header("Location: ../student/dashboard.php");
        exit();
    } else {
        $error = "Invalid Student credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Login</title>
    <style>body{background:#0f172a; color:white; font-family:Arial; text-align:center; padding:50px;}</style>
</head>
<body>
    <h2>Student Portal Login</h2>
    <?php if(isset($error)) echo "<p style='color:yellow;'>$error</p>"; ?>
    
    <form method="POST">
        <input type="text" name="username" placeholder="Student Number / Username" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <button type="submit">Login as Student</button>
    </form>
    <br>
    <a href="../login/login.php">← Other Roles</a>
</body>
</html>