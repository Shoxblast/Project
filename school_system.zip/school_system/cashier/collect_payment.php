<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireCashier();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentID     = (int)$_POST['student_id'];
    $amountPaid    = (float)$_POST['amount_paid'];
    $paymentMethod = $_POST['payment_method'];
    $referenceNo   = trim($_POST['reference_no'] ?? '');
    $notes         = trim($_POST['notes'] ?? '');

    if ($amountPaid > 0) {
        $stmt = $pdo->prepare("
            INSERT INTO payments 
            (StudentID, CashierID, AmountPaid, PaymentMethod, ReferenceNo, Notes) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $success = $stmt->execute([
            $studentID, 
            $_SESSION['user_id'], 
            $amountPaid, 
            $paymentMethod, 
            $referenceNo, 
            $notes
        ]);

        if ($success) {
            $paymentID = $pdo->lastInsertId();
            
            // Audit Log
            $pdo->prepare("INSERT INTO audit_logs 
                (UserID, Action, TableName, RecordID, NewValue, IPAddress) 
                VALUES (?, 'COLLECT_PAYMENT', 'payments', ?, ?, ?)")
                ->execute([
                    $_SESSION['user_id'], 
                    $paymentID, 
                    "₱" . number_format($amountPaid, 2), 
                    $_SERVER['REMOTE_ADDR']
                ]);

            $_SESSION['success'] = "Payment of ₱" . number_format($amountPaid, 2) . " recorded successfully!";
            header("Location: print_receipt.php?payment_id=$paymentID");
            exit();
        }
    }
}

// Get Students for Search
$students = $pdo->query("
    SELECT s.StudentID, s.StudentNumber, u.FirstName, u.LastName, 
           COALESCE(sa.TotalBalance, 0) as Balance
    FROM students s 
    JOIN users u ON s.UserID = u.UserID 
    LEFT JOIN student_accounts sa ON s.StudentID = sa.StudentID
    ORDER BY s.StudentNumber
")->fetchAll();
?>

<?php include '../includes/cashier_header.php'; ?>

<h2>💵 Collect Payment</h2>
<?php displayMessage(); ?>

<form method="POST">
    <label>Select Student:</label><br>
    <select name="student_id" required style="width:100%; padding:10px; margin-bottom:15px;">
        <option value="">-- Select Student --</option>
        <?php foreach($students as $s): ?>
        <option value="<?= $s['StudentID'] ?>">
            <?= $s['StudentNumber'] ?> - <?= $s['FirstName'] . ' ' . $s['LastName'] ?> 
            (Balance: ₱<?= number_format($s['Balance'], 2) ?>)
        </option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Amount Paid:</label><br>
    <input type="number" name="amount_paid" step="0.01" required style="width:100%; padding:10px;" placeholder="Enter amount"><br><br>

    <label>Payment Method:</label><br>
    <select name="payment_method" required style="width:100%; padding:10px;">
        <option value="Cash">Cash</option>
        <option value="GCash">GCash</option>
        <option value="Bank Transfer">Bank Transfer</option>
        <option value="Card">Card</option>
        <option value="Other">Other</option>
    </select><br><br>

    <label>Reference No. (Optional):</label><br>
    <input type="text" name="reference_no" placeholder="OR Number / Transaction ID" style="width:100%; padding:10px;"><br><br>

    <label>Notes:</label><br>
    <textarea name="notes" rows="3" style="width:100%;"></textarea><br><br>

    <button type="submit" style="padding:12px 30px; font-size:16px;">Record Payment & Print Receipt</button>
</form>

<?php include '../includes/footer.php'; ?>