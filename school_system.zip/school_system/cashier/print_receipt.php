<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireCashier();

$paymentID = $_GET['payment_id'] ?? 0;

$stmt = $pdo->prepare("
    SELECT p.*, u.FirstName as CashierName, 
           s.StudentNumber, su.FirstName, su.LastName,
           sa.TotalBalance as CurrentBalance
    FROM payments p
    JOIN users u ON p.CashierID = u.UserID
    JOIN students s ON p.StudentID = s.StudentID
    JOIN users su ON s.UserID = su.UserID
    LEFT JOIN student_accounts sa ON s.StudentID = sa.StudentID
    WHERE p.PaymentID = ?
");
$stmt->execute([$paymentID]);
$payment = $stmt->fetch();

if (!$payment) {
    die("Receipt not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Official Receipt</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .receipt { 
            width: 800px; 
            margin: 0 auto; 
            border: 2px solid #000; 
            padding: 30px; 
        }
        .header { text-align: center; border-bottom: 3px double #000; padding-bottom: 20px; }
        table { width: 100%; margin: 20px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        .total { font-size: 1.3em; font-weight: bold; }
        @media print {
            button { display: none; }
        }
    </style>
</head>
<body>
    <div class="receipt">
        <div class="header">
            <h1>OFFICIAL RECEIPT</h1>
            <p><strong>School Name</strong><br>Caraga Region</p>
        </div>

        <p><strong>Receipt No:</strong> <?= str_pad($payment['PaymentID'], 8, '0', STR_PAD_LEFT) ?></p>
        <p><strong>Date:</strong> <?= date('F d, Y h:i A', strtotime($payment['PaymentDate'])) ?></p>
        <p><strong>Student:</strong> <?= $payment['FirstName'] . ' ' . $payment['LastName'] ?> (<?= $payment['StudentNumber'] ?>)</p>

        <table>
            <tr><th>Description</th><th>Amount</th></tr>
            <tr>
                <td>Payment Received</td>
                <td>₱<?= number_format($payment['AmountPaid'], 2) ?></td>
            </tr>
        </table>

        <p class="total">Total Paid: ₱<?= number_format($payment['AmountPaid'], 2) ?></p>
        <p><strong>Payment Method:</strong> <?= $payment['PaymentMethod'] ?></p>
        <?php if($payment['ReferenceNo']): ?>
            <p><strong>Reference No:</strong> <?= htmlspecialchars($payment['ReferenceNo']) ?></p>
        <?php endif; ?>
        
        <p><strong>Current Balance:</strong> ₱<?= number_format($payment['CurrentBalance'], 2) ?></p>

        <p style="margin-top:50px;">Received by: <strong><?= $payment['CashierName'] ?></strong></p>
        <p>Thank you!</p>
    </div>

    <br><br>
    <button onclick="window.print()">🖨️ Print Receipt</button>
</body>
</html>