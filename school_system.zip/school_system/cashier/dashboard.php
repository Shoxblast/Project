<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireCashier();
include '../includes/cashier_header.php'; 
?>

<h1>Welcome, <?= htmlspecialchars($_SESSION['fullname']) ?> 👋</h1>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin: 30px 0;">
    <?php
    $totalToday = $pdo->query("SELECT SUM(AmountPaid) FROM payments WHERE DATE(PaymentDate) = CURDATE()")->fetchColumn() ?: 0;
    $totalPaymentsToday = $pdo->query("SELECT COUNT(*) FROM payments WHERE DATE(PaymentDate) = CURDATE()")->fetchColumn();
    ?>
    <div style="background:white; padding:25px; border-radius:8px; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
        <h3>Collected Today</h3>
        <h2 style="color:#10b981;">₱<?= number_format($totalToday, 2) ?></h2>
        <p><?= $totalPaymentsToday ?> transactions</p>
    </div>
</div>

<?php include '../includes/footer.php'; ?>