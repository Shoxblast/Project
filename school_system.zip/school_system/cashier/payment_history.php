<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireCashier();

$cashierID = $_SESSION['user_id'];

// Fetch Payment History for this Cashier only
$stmt = $pdo->prepare("
    SELECT p.PaymentID, p.PaymentDate, p.AmountPaid, p.PaymentMethod, 
           p.ReferenceNo, p.Notes,
           s.StudentNumber, 
           CONCAT(su.FirstName, ' ', su.LastName) as StudentName
    FROM payments p
    JOIN students s ON p.StudentID = s.StudentID
    JOIN users su ON s.UserID = su.UserID
    WHERE p.CashierID = ?
    ORDER BY p.PaymentDate DESC
");
$stmt->execute([$cashierID]);
$payments = $stmt->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<h2>📜 My Payment History</h2>
<p><strong>Cashier:</strong> <?= htmlspecialchars($_SESSION['fullname']) ?></p>

<?php if (count($payments) > 0): ?>
    <table border="1" cellpadding="12" style="width:100%;">
        <tr>
            <th>Date & Time</th>
            <th>Student</th>
            <th>Amount</th>
            <th>Method</th>
            <th>Reference No.</th>
            <th>Notes</th>
        </tr>
        <?php foreach ($payments as $p): ?>
        <tr>
            <td><?= date('M d, Y h:i A', strtotime($p['PaymentDate'])) ?></td>
            <td><?= htmlspecialchars($p['StudentNumber']) ?> - <?= htmlspecialchars($p['StudentName']) ?></td>
            <td style="font-weight:bold; color:#10b981;">
                ₱<?= number_format($p['AmountPaid'], 2) ?>
            </td>
            <td><?= htmlspecialchars($p['PaymentMethod']) ?></td>
            <td><?= htmlspecialchars($p['ReferenceNo'] ?? '-') ?></td>
            <td><?= htmlspecialchars($p['Notes'] ?? '-') ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <button onclick="window.print()">🖨️ Print Payment History</button>

<?php else: ?>
    <div style="text-align:center; padding:60px; background:#f0f0f0; border-radius:8px;">
        <h3>No payments recorded yet.</h3>
        <p><a href="collect_payment.php">Start Collecting Payments →</a></p>
    </div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>