<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/header.php';

$page_title = "My Class Schedule";
requireStudent();

$studentID = getCurrentStudentID($pdo);
?>

<h1>Class Schedule</h1>
<p><strong>Student:</strong> <?= htmlspecialchars($_SESSION['fullname']) ?></p>
<p><strong>Date:</strong> <?= date('F d, Y') ?></p>

<table border="1" cellpadding="12" style="width:100%;">
    <tr>
        <th>CN</th>
        <th>Subject</th>
        <th>Schedule</th>
        <th>Room</th>
        <th>Faculty</th>
    </tr>
    <?php
    $stmt = $pdo->prepare("
        SELECT cs.ClassNumber, s.SubjectCode, s.SubjectName, cs.Schedule, cs.Room,
               CONCAT(u.FirstName,' ',u.LastName) as Faculty
        FROM enrollments e
        JOIN class_sections cs ON e.SectionID = cs.SectionID
        JOIN subjects s ON cs.SubjectID = s.SubjectID
        LEFT JOIN faculty f ON cs.FacultyID = f.FacultyID
        LEFT JOIN users u ON f.UserID = u.UserID
        WHERE e.StudentID = ? AND e.Status = 'Enrolled'
    ");
    $stmt->execute([$studentID]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td>{$row['ClassNumber']}</td>
                <td>{$row['SubjectCode']} - {$row['SubjectName']}</td>
                <td>{$row['Schedule']}</td>
                <td>{$row['Room']}</td>
                <td>{$row['Faculty']}</td>
              </tr>";
    }
    ?>
</table>

<br><br>
<button onclick="window.print()">🖨️ Print Schedule</button>

<?php include '../includes/footer.php'; ?>