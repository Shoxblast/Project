<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireStudent();

$studentID = getCurrentStudentID($pdo);

// Get Student Account Balance
$stmt = $pdo->prepare("SELECT TotalBalance FROM student_accounts WHERE StudentID = ?");
$stmt->execute([$studentID]);
$balance = $stmt->fetchColumn() ?: 0;

// Get Payment History
$stmt = $pdo->prepare("
    SELECT p.PaymentDate, p.AmountPaid, p.PaymentMethod, p.ReferenceNo, p.Notes,
           u.FirstName as CashierName
    FROM payments p
    LEFT JOIN users u ON p.CashierID = u.UserID
    WHERE p.StudentID = ?
    ORDER BY p.PaymentDate DESC
");
$stmt->execute([$studentID]);
$payments = $stmt->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<h2>💰 Statement of Account (SOA)</h2>
<p><strong>Student:</strong> <?= htmlspecialchars($_SESSION['fullname']) ?></p>
<p><strong>Date:</strong> <?= date('F d, Y') ?></p>

<hr>

<h3>Current Balance: 
    <span style="color: <?= $balance > 0 ? 'red' : 'green'; ?>; font-size: 1.5em;">
        ₱<?= number_format($balance, 2) ?>
    </span>
</h3>

<?php if ($balance > 0): ?>
    <p style="color:red;"><strong>Note:</strong> Please settle your balance at the Cashier's Office.</p>
<?php endif; ?>

<hr>
<h3>Payment History</h3>
<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>Date</th>
        <th>Amount Paid</th>
        <th>Method</th>
        <th>Reference No.</th>
        <th>Cashier</th>
        <th>Notes</th>
    </tr>
    <?php if (count($payments) > 0): ?>
        <?php foreach ($payments as $p): ?>
        <tr>
            <td><?= date('M d, Y h:i A', strtotime($p['PaymentDate'])) ?></td>
            <td>₱<?= number_format($p['AmountPaid'], 2) ?></td>
            <td><?= $p['PaymentMethod'] ?></td>
            <td><?= $p['ReferenceNo'] ?></td>
            <td><?= $p['CashierName'] ?></td>
            <td><?= htmlspecialchars($p['Notes']) ?></td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr><td colspan="6" style="text-align:center;">No payments recorded yet.</td></tr>
    <?php endif; ?>
</table>

<br>
<button onclick="window.print()">🖨️ Print Statement of Account</button>

<?php include '../includes/footer.php'; ?>