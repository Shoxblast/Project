<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireStudent();

$studentID = getCurrentStudentID($pdo);

// Handle Enrollment Request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['section_id'])) {
    $sectionID = (int)$_POST['section_id'];
    $academicYearID = 1; // TODO: Make dynamic later

    $stmt = $pdo->prepare("
        INSERT INTO enrollments (StudentID, SectionID, AcademicYearID, Semester, EnrolledBy)
        VALUES (?, ?, ?, '1st', ?)
    ");

    try {
        $stmt->execute([$studentID, $sectionID, $academicYearID, $_SESSION['user_id']]);
        $_SESSION['success'] = "Enrollment request submitted successfully!";
    } catch (Exception $e) {
        $_SESSION['error'] = "Already enrolled or class is full.";
    }
    header("Location: enrollment.php");
    exit();
}

// Fetch Available Class Sections
$stmt = $pdo->prepare("
    SELECT cs.SectionID, cs.ClassNumber, s.SubjectCode, s.SubjectName, 
           s.Units, cs.Schedule, cs.Room, cs.MaxStudents,
           CONCAT(u.FirstName, ' ', u.LastName) as FacultyName,
           (SELECT COUNT(*) FROM enrollments WHERE SectionID = cs.SectionID) as EnrolledCount
    FROM class_sections cs
    JOIN subjects s ON cs.SubjectID = s.SubjectID
    LEFT JOIN faculty f ON cs.FacultyID = f.FacultyID
    LEFT JOIN users u ON f.UserID = u.UserID
    WHERE cs.AcademicYearID = 1  -- Change to active academic year later
    ORDER BY s.SubjectCode
");
$stmt->execute();
$availableSections = $stmt->fetchAll();
?>

<?php include '../includes/student_header.php'; ?>

<h1>📝 Subject Enrollment</h1>

<?php displayMessage(); ?>

<h3>Available Subjects / Class Sections</h3>

<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>CN</th>
        <th>Subject</th>
        <th>Units</th>
        <th>Schedule</th>
        <th>Room</th>
        <th>Faculty</th>
        <th>Slots</th>
        <th>Action</th>
    </tr>
    <?php foreach ($availableSections as $sec): 
        $slotsLeft = $sec['MaxStudents'] - $sec['EnrolledCount'];
    ?>
    <tr>
        <td><?= htmlspecialchars($sec['ClassNumber']) ?></td>
        <td><strong><?= htmlspecialchars($sec['SubjectCode']) ?></strong> - <?= htmlspecialchars($sec['SubjectName']) ?></td>
        <td align="center"><?= $sec['Units'] ?></td>
        <td><?= htmlspecialchars($sec['Schedule'] ?? 'TBA') ?></td>
        <td><?= htmlspecialchars($sec['Room'] ?? 'TBA') ?></td>
        <td><?= htmlspecialchars($sec['FacultyName'] ?? 'TBA') ?></td>
        <td align="center"><?= $slotsLeft ?>/<?= $sec['MaxStudents'] ?></td>
        <td>
            <form method="POST" style="margin:0;">
                <input type="hidden" name="section_id" value="<?= $sec['SectionID'] ?>">
                <button type="submit" <?= $slotsLeft <= 0 ? 'disabled' : '' ?>>
                    <?= $slotsLeft <= 0 ? 'Full' : 'Enroll' ?>
                </button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php if (empty($availableSections)): ?>
    <p>No class sections available yet. Please contact your Dean.</p>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>