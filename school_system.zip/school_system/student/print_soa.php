<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireStudent();

$studentID = getCurrentStudentID($pdo);

$stmt = $pdo->prepare("SELECT TotalBalance FROM student_accounts WHERE StudentID = ?");
$stmt->execute([$studentID]);
$balance = $stmt->fetchColumn() ?: 0;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Statement of Account</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1, h2 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #333; padding: 10px; }
        .balance { font-size: 1.8em; color: red; text-align: center; }
        @media print { button { display: none; } }
    </style>
</head>
<body>
    <h1>Statement of Account (SOA)</h1>
    <p style="text-align:center;"><strong><?= htmlspecialchars($_SESSION['fullname']) ?></strong></p>
    <p style="text-align:center;">Date: <?= date('F d, Y') ?></p>

    <div class="balance">
        Current Balance: ₱<?= number_format($balance, 2) ?>
    </div>

    <h2>Payment History</h2>
    <!-- You can expand this with payment history like in soa.php -->

    <br><br>
    <button onclick="window.print()">Print SOA</button>
</body>
</html>