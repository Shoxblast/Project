<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireStudent();

$studentID = getCurrentStudentID($pdo);

// Fetch Enrolled Subjects (Study Load)
$stmt = $pdo->prepare("
    SELECT 
        cs.ClassNumber,
        s.SubjectCode,
        s.SubjectName,
        s.Units,
        cs.Schedule,
        cs.Room,
        CONCAT(u.FirstName, ' ', u.LastName) as FacultyName,
        e.Status,
        e.EnrolledAt
    FROM enrollments e
    JOIN class_sections cs ON e.SectionID = cs.SectionID
    JOIN subjects s ON cs.SubjectID = s.SubjectID
    LEFT JOIN faculty f ON cs.FacultyID = f.FacultyID
    LEFT JOIN users u ON f.UserID = u.UserID
    WHERE e.StudentID = ? AND e.Status = 'Enrolled'
    ORDER BY s.SubjectCode
");
$stmt->execute([$studentID]);
$subjects = $stmt->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<h1>📚 My Study Load / Schedule</h1>
<p><strong>Student:</strong> <?= htmlspecialchars($_SESSION['fullname']) ?></p>

<?php if (count($subjects) > 0): ?>
    <table border="1" cellpadding="12" style="width:100%; margin-top:20px;">
        <tr>
            <th>CN</th>
            <th>Subject Code</th>
            <th>Subject Name</th>
            <th>Units</th>
            <th>Schedule</th>
            <th>Room</th>
            <th>Faculty</th>
            <th>Enrolled Date</th>
        </tr>
        <?php foreach ($subjects as $row): ?>
        <tr>
            <td><?= htmlspecialchars($row['ClassNumber']) ?></td>
            <td><strong><?= htmlspecialchars($row['SubjectCode']) ?></strong></td>
            <td><?= htmlspecialchars($row['SubjectName']) ?></td>
            <td align="center"><?= $row['Units'] ?></td>
            <td><?= htmlspecialchars($row['Schedule'] ?? '<span style="color:orange;">TBA</span>') ?></td>
            <td><?= htmlspecialchars($row['Room'] ?? '<span style="color:orange;">TBA</span>') ?></td>
            <td><?= htmlspecialchars($row['FacultyName'] ?? '<span style="color:orange;">TBA</span>') ?></td>
            <td><?= date('M d, Y', strtotime($row['EnrolledAt'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <button onclick="window.print()">🖨️ Print Study Load</button>

<?php else: ?>
    <div style="text-align:center; padding:60px; background:#f0f0f0; border-radius:8px;">
        <h3>You have not enrolled in any subjects yet.</h3>
        <p><a href="enrollment.php" style="font-size:18px;">→ Browse Available Subjects</a></p>
    </div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
<?php include '../includes/footer.php'; ?>