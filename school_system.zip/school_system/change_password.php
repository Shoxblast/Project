<?php
require_once 'config/db.php';
require_once 'includes/session.php';
requireLogin();   // Any logged-in user can change password

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $currentPassword = $_POST['current_password'];
    $newPassword     = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($newPassword !== $confirmPassword) {
        $_SESSION['error'] = "New passwords do not match!";
        header("Location: change_password.php");
        exit();
    }

    // Verify current password
    $stmt = $pdo->prepare("SELECT PasswordHash FROM users WHERE UserID = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($currentPassword, $user['PasswordHash'])) {
        $_SESSION['error'] = "Current password is incorrect!";
        header("Location: change_password.php");
        exit();
    }

    // Update password
    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET PasswordHash = ? WHERE UserID = ?");
    
    if ($stmt->execute([$newHash, $_SESSION['user_id']])) {
        $_SESSION['success'] = "✅ Password changed successfully!";
        header("Location: " . (isStudent() ? "student/dashboard.php" : 
                             (isDean() ? "dean/dashboard.php" : 
                             (isFaculty() ? "faculty/dashboard.php" : 
                             (isFinance() ? "finance/dashboard.php" : 
                             (isCashier() ? "cashier/dashboard.php" : "index.php"))))));
        exit();
    } else {
        $_SESSION['error'] = "Failed to update password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Change Password</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f8fafc; }
        .form-container {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ccc; border-radius: 6px; }
        button { width: 100%; padding: 14px; background: #1e40af; color: white; border: none; border-radius: 6px; font-size: 16px; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>🔑 Change Password</h2>
    <?php displayMessage(); ?>

    <form method="POST">
        <label>Current Password</label>
        <input type="password" name="current_password" required>

        <label>New Password</label>
        <input type="password" name="new_password" required minlength="6">

        <label>Confirm New Password</label>
        <input type="password" name="confirm_password" required minlength="6">

        <button type="submit">Update Password</button>
    </form>

    <br>
    <a href="javascript:history.back()">← Go Back</a>
</div>

</body>
</html>