<?php
// includes/sidebar_menu.php - Dynamic Menu based on Role
$role = $_SESSION['role'] ?? '';

switch ($role) {
    case 'admin':
        ?>
        <a href="../admin/dashboard.php">🏠 Dashboard</a>
        <a href="../login/register_staff.php">👤 Register Staff</a>
        <a href="../login/register_student.php">🎓 Register Student</a>
        <?php
        break;

    case 'dean':
        ?>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="courses.php">📚 Courses</a>
        <a href="subjects.php">📖 Subjects</a>
        <a href="sections.php">🔢 Class Sections</a>
        <a href="faculty.php">👨‍🏫 Faculty</a>
        <a href="students.php">👨‍🎓 Students</a>
        <?php
        break;

    case 'faculty':
        ?>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="my_classes.php">📚 My Classes</a>
        <a href="grade_entry.php">📝 Enter Grades</a>
        <?php
        break;

    case 'finance':
        ?>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="student_balance.php">👨‍🎓 Student Balances</a>
        <a href="fees.php">💰 Manage Fees</a>
        <a href="scholarships.php">🎓 Scholarships</a>
        <a href="payments.php">💵 Payment History</a>
        <?php
        break;

    case 'cashier':
        ?>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="collect_payment.php">💵 Collect Payment</a>
        <a href="payment_history.php">📜 Payment History</a>
        <?php
        break;

    case 'student':
        ?>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="schedule.php">📅 My Schedule</a>
        <a href="enrollment.php">📝 Enroll Subjects</a>
        <a href="soa.php">💰 Statement of Account</a>
        <?php
        break;
}
?>