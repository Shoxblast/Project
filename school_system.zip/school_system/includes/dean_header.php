<?php 
require_once '../includes/session.php';
requireDean(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dean Portal</title>
    <style>
        body {font-family: Arial, sans-serif; margin:0;}
        .sidebar {
            width: 260px; background: #1e40af; color: white; 
            position: fixed; height: 100%; padding: 20px; overflow-y: auto;
        }
        .sidebar a {
            color: white; text-decoration: none; display: block; 
            padding: 12px; border-radius: 5px; margin: 5px 0;
        }
        .sidebar a:hover { background: #3b82f6; }
        .content { margin-left: 280px; padding: 20px; }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>👨‍💼 Dean Portal</h2>
    <p><strong><?= htmlspecialchars($_SESSION['fullname']) ?></strong></p>
    <hr>
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="courses.php">📚 Courses</a>
    <a href="subjects.php">📖 Subjects</a>
    <a href="sections.php">🔢 Class Sections (CN)</a>
    <a href="faculty.php">👨‍🏫 Faculty</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<div class="content">