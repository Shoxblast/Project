<?php
// includes/header.php - Global Header with Dynamic Sidebar
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/auth.php';

requireLogin(); // Ensure user is logged in
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'School Management System' ?> - Jobart Gay College</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Arial', sans-serif;
            background: #f8fafc;
            margin: 0;
        }
        .sidebar {
            width: 260px;
            background: #1e40af;
            color: white;
            position: fixed;
            height: 100vh;
            padding: 20px;
            overflow-y: auto;
        }
        .sidebar h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        .sidebar p {
            text-align: center;
            margin-bottom: 20px;
            opacity: 0.9;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 12px 15px;
            border-radius: 6px;
            margin: 6px 0;
        }
        .sidebar a:hover {
            background: #3b82f6;
        }
        .content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
        }
        .header-top {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .alert {
            padding: 12px 20px;
            margin: 15px 0;
            border-radius: 6px;
            font-weight: bold;
        }
        .alert.success { background: #d4edda; color: #155724; }
        .alert.error   { background: #f8d7da; color: #721c24; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th { background: #f1f5f9; }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>🏫 Jobart Gay College</h2>
    <p><strong><?= htmlspecialchars($_SESSION['fullname']) ?></strong></p>
    <p><small><?= ucfirst($_SESSION['role']) ?> Portal</small></p>
    <hr style="border-color: rgba(255,255,255,0.2); margin: 15px 0;">

    <?php include __DIR__ . '/sidebar_menu.php'; ?>
    
    <hr style="border-color: rgba(255,255,255,0.2); margin: 15px 0;">
    <a href="../change_password.php">🔑 Change Password</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<div class="content">
    <div class="header-top">
        <h1><?= $page_title ?? 'Dashboard' ?></h1>
    </div>

    <?php displayMessage(); ?>