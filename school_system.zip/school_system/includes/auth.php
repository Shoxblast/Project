<?php
// includes/auth.php - Centralized Authentication & Role Management

require_once __DIR__ . '/session.php';

// Login User (Call this after successful password verification)
function loginUser($user) {
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);

    $_SESSION['user_id']      = $user['UserID'];
    $_SESSION['username']     = $user['Username'];
    $_SESSION['role']         = $user['Role'];
    $_SESSION['fullname']     = trim($user['FirstName'] . ' ' . $user['LastName']);
    $_SESSION['department_id']= $user['DepartmentID'] ?? null;

    // Store additional role-specific data
    if ($user['Role'] === 'student') {
        // Student-specific data can be loaded later via getCurrentStudentID()
    } elseif ($user['Role'] === 'faculty') {
        // Can preload faculty_id if needed
    }
}

// Redirect user based on their role
function redirectByRole($role) {
    switch ($role) {
        case 'admin':
            header("Location: ../admin/dashboard.php");
            break;
        case 'dean':
            header("Location: ../dean/dashboard.php");
            break;
        case 'faculty':
            header("Location: ../faculty/dashboard.php");
            break;
        case 'finance':
            header("Location: ../finance/dashboard.php");
            break;
        case 'cashier':
            header("Location: ../cashier/dashboard.php");
            break;
        case 'student':
            header("Location: ../student/dashboard.php");
            break;
        default:
            header("Location: ../index.php");
    }
    exit();
}