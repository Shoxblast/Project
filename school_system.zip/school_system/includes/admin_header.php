<?php 
require_once '../includes/session.php';
requireAdmin(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Portal - School System</title>
    <style>
        body {font-family: Arial, sans-serif; margin:0; background: #f8fafc;}
        .sidebar {
            width: 260px; background: #1e40af; color: white; 
            position: fixed; height: 100%; padding: 20px; overflow-y: auto;
        }
        .sidebar a {
            color: white; text-decoration: none; display: block; 
            padding: 12px; border-radius: 5px; margin: 5px 0;
        }
        .sidebar a:hover { background: #3b82f6; }
        .content { margin-left: 280px; padding: 30px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>⚙️ Admin Portal</h2>
    <p><strong><?= htmlspecialchars($_SESSION['fullname'] ?? 'Administrator') ?></strong></p>
    <hr>
    <a href="register_staff.php">👤 Register Staff</a>
    <a href="register_student.php">🎓 Register Student</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<div class="content">