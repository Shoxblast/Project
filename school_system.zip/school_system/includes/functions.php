<?php
// includes/functions.php

function generateControlNumber($pdo) {
    $stmt = $pdo->query("SELECT MAX(CN_Number) as last_cn FROM class_sections");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $next = ($result['last_cn'] ?? 0) + 1;
    return str_pad($next, 8, '0', STR_PAD_LEFT);
}

function getAcademicYears($pdo) {
    $stmt = $pdo->query("SELECT AcademicYearID, YearName FROM academic_years ORDER BY YearName DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>