<?php
// includes/session.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ======================
// HELPER FUNCTIONS
// ======================

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: ../login/login.php");
        exit();
    }
}

function displayMessage() {
    if (isset($_SESSION['success'])) {
        echo "<div class='alert success'>" . $_SESSION['success'] . "</div>";
        unset($_SESSION['success']);
    }
    if (isset($_SESSION['error'])) {
        echo "<div class='alert error'>" . $_SESSION['error'] . "</div>";
        unset($_SESSION['error']);
    }
}

// ======================
// ROLE CHECKERS
// ======================

function getUserRole() {
    return $_SESSION['role'] ?? null;
}

function isAdmin()     { return getUserRole() === 'admin'; }
function isDean()      { return getUserRole() === 'dean'; }
function isFaculty()   { return getUserRole() === 'faculty'; }
function isFinance()   { return getUserRole() === 'finance'; }
function isCashier()   { return getUserRole() === 'cashier'; }
function isStudent()   { return getUserRole() === 'student'; }

// Role Requirement Functions
function requireAdmin()  { requireLogin(); if (!isAdmin())  { header("Location: ../login/login.php"); exit(); } }
function requireDean()   { requireLogin(); if (!isDean())   { header("Location: ../login/login.php"); exit(); } }
function requireFaculty(){ requireLogin(); if (!isFaculty()){ header("Location: ../login/login.php"); exit(); } }
function requireFinance(){ requireLogin(); if (!isFinance()){ header("Location: ../login/login.php"); exit(); } }
function requireCashier(){ requireLogin(); if (!isCashier()){ header("Location: ../login/login.php"); exit(); } }
function requireStudent(){ requireLogin(); if (!isStudent()){ header("Location: ../login/login.php"); exit(); } }

// ======================
// USER INFO HELPERS
// ======================

function getCurrentUserID() {
    return $_SESSION['user_id'] ?? null;
}

function getCurrentStudentID($pdo) {
    if (!isset($_SESSION['student_id'])) {
        $stmt = $pdo->prepare("SELECT StudentID FROM students WHERE UserID = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $_SESSION['student_id'] = $stmt->fetchColumn();
    }
    return $_SESSION['student_id'] ?? null;
}

// Optional: Logout function
function logout() {
    session_unset();
    session_destroy();
    header("Location: ../index.php");
    exit();
}