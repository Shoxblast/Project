<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: ../login/login.php");
        exit();
    }
}

// Role Checkers
function isAdmin()     { return isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; }
function isDean()      { return isset($_SESSION['role']) && $_SESSION['role'] === 'dean'; }
function isFinance()   { return isset($_SESSION['role']) && $_SESSION['role'] === 'finance'; }
function isCashier()   { return isset($_SESSION['role']) && $_SESSION['role'] === 'cashier'; }
function isFaculty()   { return isset($_SESSION['role']) && $_SESSION['role'] === 'faculty'; }
function isStudent()   { return isset($_SESSION['role']) && $_SESSION['role'] === 'student'; }

// Role Requirements
function requireAdmin()  { requireLogin(); if (!isAdmin())  { header("Location: ../login/login.php"); exit(); } }
function requireDean()   { requireLogin(); if (!isDean())   { header("Location: ../login/login.php"); exit(); } }
function requireFinance(){ requireLogin(); if (!isFinance()){ header("Location: ../login/login.php"); exit(); } }
function requireCashier(){ requireLogin(); if (!isCashier()){ header("Location: ../login/login.php"); exit(); } }
function requireFaculty(){ requireLogin(); if (!isFaculty()){ header("Location: ../login/login.php"); exit(); } }
function requireStudent(){ requireLogin(); if (!isStudent()){ header("Location: ../login/login.php"); exit(); } }

// Helper Functions
function getCurrentStudentID($pdo) {
    if (!isset($_SESSION['student_id'])) {
        $stmt = $pdo->prepare("SELECT StudentID FROM students WHERE UserID = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $_SESSION['student_id'] = $stmt->fetchColumn();
    }
    return $_SESSION['student_id'];
}

function displayMessage() {
    if (isset($_SESSION['success'])) {
        echo "<p style='color:green; font-weight:bold; padding:10px; background:#d4edda; border-radius:5px;'>" . $_SESSION['success'] . "</p>";
        unset($_SESSION['success']);
    }
    if (isset($_SESSION['error'])) {
        echo "<p style='color:red; font-weight:bold; padding:10px; background:#f8d7da; border-radius:5px;'>" . $_SESSION['error'] . "</p>";
        unset($_SESSION['error']);
    }
}
?>