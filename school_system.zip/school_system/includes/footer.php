<?php
// includes/footer.php
?>
    </div> <!-- End of .content -->

    <footer style="
        text-align: center;
        padding: 20px;
        background: #1e40af;
        color: white;
        margin-top: 40px;
        font-size: 0.9em;
    ">
        &copy; <?= date('Y') ?> Jobart Gay College • School Management System
    </footer>
</body>
</html>