<?php
// includes/footer.php
?>
    </div> <!-- End of .content -->

    <footer style="text-align:center; padding:25px; background:#1e40af; color:white; margin-top:50px;">
        <p>&copy; <?= date('Y') ?> School Management System | All Rights Reserved</p>
    </footer>
</body>
</html>