<?php 
require_once 'config/db.php';
require_once 'includes/session.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobart Gay College</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #1e3a8a, #3b82f6);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container { text-align: center; max-width: 1000px; padding: 40px 20px; }
        h1 { font-size: 3.5rem; margin-bottom: 10px; }
        .subtitle { font-size: 1.4rem; margin-bottom: 50px; opacity: 0.9; }
        .cards {
            display: flex;
            justify-content: center;
            gap: 25px;
            flex-wrap: wrap;
        }
        .card {
            background: rgba(255,255,255,0.95);
            color: #1e3a8a;
            width: 320px;
            padding: 35px 25px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transition: transform 0.3s;
        }
        .card:hover { transform: translateY(-10px); }
        .card h2 { margin: 0 0 15px 0; color: #1e40af; }
        .card p { color: #555; margin-bottom: 25px; min-height: 50px; }
        .btn {
            display: inline-block;
            padding: 14px 32px;
            background: #1e40af;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 1.1rem;
            margin: 5px;
            transition: all 0.3s;
        }
        .btn:hover { background: #2563eb; transform: scale(1.05); }
        .btn-secondary { background: #64748b; }
        footer { margin-top: 80px; opacity: 0.8; font-size: 0.9rem; }
    </style>
</head>
<body>

<div class="container">
    <h1>📚 Jobart Gay College</h1>
    <p class="subtitle">Caraga Region | Empowering Education Through Technology</p>

    <div class="cards">

        <!-- Staff Portal -->
        <div class="card">
            <h2>👨‍💼 Staff Portal</h2>
            <p>Deans, Faculty, Finance, Cashiers & Admin</p>
            <a href="login/login.php" class="btn">Staff Login</a>
            <a href="login/register_staff.php" class="btn btn-secondary">Register Staff</a>
        </div>

        <!-- Student Portal -->
        <div class="card">
            <h2>🎓 Student Portal</h2>
            <p>Access Schedule, Grades & Statement of Account</p>
            <a href="login/student-login.php" class="btn">Student Login</a>
            <a href="login/register_student.php" class="btn btn-secondary">New Student Registration</a>
        </div>

    </div>

    <footer>
        &copy; <?= date('Y') ?> Jobart Gay College • All Rights Reserved
    </footer>
</div>

</body>
</html>