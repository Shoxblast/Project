<?php
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

$check = $pdo->query("SELECT COUNT(*) FROM academic_years")->fetchColumn();

if ($check == 0) {
    $pdo->prepare("INSERT INTO academic_years (YearName, StartDate, EndDate, IsActive) VALUES (?, ?, ?, 1)")
         ->execute(['2026-2027', '2026-06-01', '2027-05-31']);
    echo "<h2>✅ Academic Year 2026-2027 Created!</h2>";
} else {
    echo "<h2>✅ Academic Year Already Exists</h2>";
}
echo "<br><a href='sections.php'>→ Go to Class Sections</a>";
?>