<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $code = strtoupper(trim($_POST['course_code']));
    $name = trim($_POST['course_name']);

    $stmt = $pdo->prepare("
        INSERT INTO courses (CourseCode, CourseName, DepartmentID, CreatedBy) 
        VALUES (?, ?, ?, ?)
    ");

    if ($stmt->execute([$code, $name, $_SESSION['department_id'], $_SESSION['user_id']])) {
        $_SESSION['success'] = "Course created successfully!";
    } else {
        $_SESSION['error'] = "Failed to create course. Code may already exist.";
    }
    header("Location: courses.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>📚 Manage Courses</h2>
<?php displayMessage(); ?>

<form method="POST">
    <input type="text" name="course_code" placeholder="Course Code (e.g. BSIT)" required>
    <input type="text" name="course_name" placeholder="Course Name (e.g. Bachelor of Science in Information Technology)" required style="width:500px;">
    <button type="submit">Create Course</button>
</form>

<hr>
<h3>Existing Courses</h3>
<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>Course Code</th>
        <th>Course Name</th>
    </tr>
    <?php
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE DepartmentID = ? ORDER BY CourseCode");
    $stmt->execute([$_SESSION['department_id']]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td><strong>{$row['CourseCode']}</strong></td>
                <td>{$row['CourseName']}</td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>