<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

$dept_id = $_SESSION['department_id'];

// Create Course
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_course'])) {
    $code = strtoupper(trim($_POST['course_code']));
    $name = trim($_POST['course_name']);

    $stmt = $pdo->prepare("INSERT INTO courses (CourseCode, CourseName, DepartmentID, CreatedBy) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$code, $name, $dept_id, $_SESSION['user_id']])) {
        $_SESSION['success'] = "✅ Course created successfully!";
    } else {
        $_SESSION['error'] = "Course code already exists.";
    }
    header("Location: courses.php");
    exit();
}

// Delete Course
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM courses WHERE CourseID = ? AND DepartmentID = ?")
         ->execute([$id, $dept_id]);
    $_SESSION['success'] = "✅ Course deleted successfully.";
    header("Location: courses.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>📚 Manage Courses</h2>
<?php displayMessage(); ?>

<form method="POST" style="margin-bottom: 30px;">
    <input type="text" name="course_code" placeholder="Course Code (e.g. BSIT)" required>
    <input type="text" name="course_name" placeholder="Full Course Name" required style="width:500px;">
    <button type="submit" name="add_course">Create Course</button>
</form>

<h3>Existing Courses</h3>
<table border="1" cellpadding="12" style="width:100%;">
    <tr>
        <th>Course Code</th>
        <th>Course Name</th>
        <th>Actions</th>
    </tr>
    <?php
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE DepartmentID = ? ORDER BY CourseCode");
    $stmt->execute([$dept_id]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td><strong>{$row['CourseCode']}</strong></td>
                <td>{$row['CourseName']}</td>
                <td>
                    <a href='?delete={$row['CourseID']}' onclick=\"return confirm('Delete this course?')\">Delete</a>
                </td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>