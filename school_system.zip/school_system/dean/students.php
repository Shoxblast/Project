<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_student'])) {
    $studentNumber = trim($_POST['student_number']);
    $fname = trim($_POST['first_name']);
    $lname = trim($_POST['last_name']);
    $email = trim($_POST['email']);

    $passwordHash = password_hash('password123', PASSWORD_DEFAULT);

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            INSERT INTO users (Username, PasswordHash, Role, FirstName, LastName, Email, DepartmentID) 
            VALUES (?, ?, 'student', ?, ?, ?, ?)
        ");
        $stmt->execute([$studentNumber, $passwordHash, $fname, $lname, $email, $_SESSION['department_id']]);
        $userID = $pdo->lastInsertId();

        $stmt2 = $pdo->prepare("
            INSERT INTO students (UserID, StudentNumber, Status) 
            VALUES (?, ?, 'Active')
        ");
        $stmt2->execute([$userID, $studentNumber]);

        $pdo->prepare("INSERT INTO student_accounts (StudentID, TotalBalance) VALUES (LAST_INSERT_ID(), 0)")->execute();

        $pdo->commit();

        $_SESSION['success'] = "Student added successfully!<br>Default Password: <strong>password123</strong>";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to add student. Student number may already exist.";
    }

    header("Location: students.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>👨‍🎓 Manage Students</h2>
<?php displayMessage(); ?>

<form method="POST">
    <input type="text" name="student_number" placeholder="Student Number" required>
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="last_name" placeholder="Last Name" required>
    <input type="email" name="email" placeholder="Email">
    <button type="submit" name="add_student">Add New Student</button>
</form>

<hr>
<h3>Current Students in Department</h3>
<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>Student No.</th>
        <th>Name</th>
        <th>Email</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php
    $stmt = $pdo->prepare("
        SELECT s.StudentID, s.StudentNumber, u.FirstName, u.LastName, u.Email, s.Status 
        FROM students s 
        JOIN users u ON s.UserID = u.UserID 
        WHERE u.DepartmentID = ? 
        ORDER BY s.StudentNumber
    ");
    $stmt->execute([$_SESSION['department_id']]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td>{$row['StudentNumber']}</td>
                <td>{$row['FirstName']} {$row['LastName']}</td>
                <td>{$row['Email']}</td>
                <td>{$row['Status']}</td>
                <td><a href='enroll_student.php?student_id={$row['StudentID']}'>Enroll</a></td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>