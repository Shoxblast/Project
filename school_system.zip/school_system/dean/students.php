<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

$dept_id = $_SESSION['department_id'];

// Add New Student
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_student'])) {
    $studentNumber = trim($_POST['student_number']);
    $fname = trim($_POST['first_name']);
    $lname = trim($_POST['last_name']);
    $email = trim($_POST['email']);

    $passwordHash = password_hash('password123', PASSWORD_DEFAULT);

    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("INSERT INTO users (Username, PasswordHash, Role, FirstName, LastName, Email, DepartmentID) 
                               VALUES (?, ?, 'student', ?, ?, ?, ?)");
        $stmt->execute([$studentNumber, $passwordHash, $fname, $lname, $email, $dept_id]);
        $userID = $pdo->lastInsertId();

        $pdo->prepare("INSERT INTO students (UserID, StudentNumber) VALUES (?, ?)")->execute([$userID, $studentNumber]);
        $pdo->prepare("INSERT INTO student_accounts (StudentID) VALUES (LAST_INSERT_ID())")->execute();

        $pdo->commit();
        $_SESSION['success'] = "✅ Student added! Default Password: <strong>password123</strong>";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Student number may already exist.";
    }
    header("Location: students.php");
    exit();
}

// Delete Student
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM students WHERE StudentID = ? AND (SELECT DepartmentID FROM users WHERE UserID = students.UserID) = ?")
         ->execute([$id, $dept_id]);
    $_SESSION['success'] = "Student deleted.";
    header("Location: students.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>👨‍🎓 Manage Students</h2>
<?php displayMessage(); ?>

<form method="POST">
    <input type="text" name="student_number" placeholder="Student Number" required>
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="last_name" placeholder="Last Name" required>
    <input type="email" name="email" placeholder="Email">
    <button type="submit" name="add_student">Add New Student</button>
</form>

<hr>
<h3>Current Students</h3>
<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>Student No.</th>
        <th>Name</th>
        <th>Email</th>
        <th>Actions</th>
    </tr>
    <?php
    $stmt = $pdo->prepare("
        SELECT s.StudentID, s.StudentNumber, u.FirstName, u.LastName, u.Email 
        FROM students s 
        JOIN users u ON s.UserID = u.UserID 
        WHERE u.DepartmentID = ? 
        ORDER BY s.StudentNumber
    ");
    $stmt->execute([$dept_id]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td>{$row['StudentNumber']}</td>
                <td>{$row['FirstName']} {$row['LastName']}</td>
                <td>{$row['Email']}</td>
                <td>
                    <a href='enroll_student.php?student_id={$row['StudentID']}'>Enroll</a> |
                    <a href='?delete={$row['StudentID']}' onclick=\"return confirm('Delete student?')\">Delete</a>
                </td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>