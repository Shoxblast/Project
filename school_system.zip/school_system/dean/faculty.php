<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

$dept_id = $_SESSION['department_id'];

// Create Faculty
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_faculty'])) {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $fname    = trim($_POST['first_name']);
    $lname    = trim($_POST['last_name']);
    $email    = trim($_POST['email']);
    $position = trim($_POST['position']);

    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("INSERT INTO users (Username, PasswordHash, Role, FirstName, LastName, Email, DepartmentID) 
                               VALUES (?, ?, 'faculty', ?, ?, ?, ?)");
        $stmt->execute([$username, $password, $fname, $lname, $email, $dept_id]);
        $newUserID = $pdo->lastInsertId();

        $pdo->prepare("INSERT INTO faculty (UserID, Position) VALUES (?, ?)")->execute([$newUserID, $position]);

        $pdo->commit();
        $_SESSION['success'] = "✅ Faculty member created successfully!";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to create faculty (username may already exist).";
    }
    header("Location: faculty.php");
    exit();
}

// Delete Faculty
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM faculty WHERE FacultyID = ?")->execute([$id]);
    $_SESSION['success'] = "Faculty deleted.";
    header("Location: faculty.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>👨‍🏫 Manage Faculty</h2>
<?php displayMessage(); ?>

<form method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="last_name" placeholder="Last Name" required>
    <input type="email" name="email" placeholder="Email">
    <input type="text" name="position" placeholder="Position (e.g. Professor)" required>
    <button type="submit" name="add_faculty">Add Faculty</button>
</form>

<hr>
<h3>Current Faculty Members</h3>
<table border="1" cellpadding="10" style="width:100%;">
    <tr><th>Name</th><th>Position</th><th>Email</th><th>Username</th><th>Actions</th></tr>
    <?php
    $stmt = $pdo->prepare("
        SELECT f.FacultyID, u.FirstName, u.LastName, u.Email, u.Username, f.Position 
        FROM users u 
        JOIN faculty f ON u.UserID = f.UserID 
        WHERE u.DepartmentID = ?
    ");
    $stmt->execute([$dept_id]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td>{$row['FirstName']} {$row['LastName']}</td>
                <td>{$row['Position']}</td>
                <td>{$row['Email']}</td>
                <td>{$row['Username']}</td>
                <td>
                    <a href='?delete={$row['FacultyID']}' onclick=\"return confirm('Delete this faculty?')\">Delete</a>
                </td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>