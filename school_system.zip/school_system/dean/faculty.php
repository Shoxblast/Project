<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $fname    = trim($_POST['first_name']);
    $lname    = trim($_POST['last_name']);
    $email    = trim($_POST['email']);
    $position = trim($_POST['position']);

    try {
        $stmt = $pdo->prepare("
            INSERT INTO users (Username, PasswordHash, Role, FirstName, LastName, Email, DepartmentID) 
            VALUES (?, ?, 'faculty', ?, ?, ?, ?)
        ");
        $stmt->execute([$username, $password, $fname, $lname, $email, $_SESSION['department_id']]);
        $newUserID = $pdo->lastInsertId();

        $pdo->prepare("INSERT INTO faculty (UserID, Position) VALUES (?, ?)")->execute([$newUserID, $position]);

        $_SESSION['success'] = "Faculty member created successfully!";
    } catch (Exception $e) {
        $_SESSION['error'] = "Failed to create faculty. Username may already exist.";
    }
    header("Location: faculty.php");
    exit();
}

include '../includes/dean_header.php'; 
?>

<h2>👨‍🏫 Manage Faculty</h2>
<?php displayMessage(); ?>

<form method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="last_name" placeholder="Last Name" required>
    <input type="email" name="email" placeholder="Email Address">
    <input type="text" name="position" placeholder="Position (e.g. Professor)" required>
    <button type="submit">Add Faculty Member</button>
</form>

<hr>
<h3>Current Faculty Members</h3>
<table border="1" cellpadding="10" style="width:100%;">
    <tr><th>Name</th><th>Position</th><th>Email</th><th>Username</th></tr>
    <?php
    $stmt = $pdo->prepare("
        SELECT u.FirstName, u.LastName, u.Email, u.Username, f.Position 
        FROM users u 
        JOIN faculty f ON u.UserID = f.UserID 
        WHERE u.DepartmentID = ?
    ");
    $stmt->execute([$_SESSION['department_id']]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td>{$row['FirstName']} {$row['LastName']}</td>
                <td>{$row['Position']}</td>
                <td>{$row['Email']}</td>
                <td>{$row['Username']}</td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>