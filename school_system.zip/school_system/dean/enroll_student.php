<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

$studentID = $_GET['student_id'] ?? 0;

$stmt = $pdo->prepare("SELECT s.*, u.FirstName, u.LastName FROM students s JOIN users u ON s.UserID = u.UserID WHERE s.StudentID = ?");
$stmt->execute([$studentID]);
$student = $stmt->fetch();

if (!$student) die("Student not found.");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sectionID = $_POST['section_id'];
    $ayID = $_POST['academic_year_id'];
    $semester = $_POST['semester'];

    $stmt = $pdo->prepare("
        INSERT INTO enrollments (StudentID, SectionID, AcademicYearID, Semester, EnrolledBy) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    if ($stmt->execute([$studentID, $sectionID, $ayID, $semester, $_SESSION['user_id']])) {
        $_SESSION['success'] = "Student successfully enrolled!";
    } else {
        $_SESSION['error'] = "Enrollment failed (may already be enrolled).";
    }
    header("Location: enroll_student.php?student_id=$studentID");
    exit();
}

include '../includes/header.php'; 
?>

<h2>Enroll Student in Class</h2>
<p><strong>Student:</strong> <?= htmlspecialchars($student['FirstName'] . ' ' . $student['LastName']) ?> 
   (<?= htmlspecialchars($student['StudentNumber']) ?>)</p>

<?php displayMessage(); ?>

<form method="POST">
    <select name="section_id" required>
        <option value="">Select Class Section</option>
        <?php
        $stmt = $pdo->prepare("
            SELECT cs.SectionID, cs.ClassNumber, s.SubjectCode, s.SubjectName, 
                   cs.Schedule, cs.Room 
            FROM class_sections cs 
            JOIN subjects s ON cs.SubjectID = s.SubjectID 
            WHERE cs.DepartmentID = ?
        ");
        $stmt->execute([$_SESSION['department_id']]);
        while ($row = $stmt->fetch()) {
            echo "<option value='{$row['SectionID']}'>
                    {$row['ClassNumber']} - {$row['SubjectCode']} - {$row['SubjectName']}
                  </option>";
        }
        ?>
    </select><br><br>

    <select name="academic_year_id" required>
        <?php
        $years = $pdo->query("SELECT * FROM academic_years ORDER BY YearName DESC")->fetchAll();
        foreach ($years as $y) {
            echo "<option value='{$y['AcademicYearID']}'>{$y['YearName']}</option>";
        }
        ?>
    </select><br><br>

    <select name="semester" required>
        <option value="1st">1st Semester</option>
        <option value="2nd">2nd Semester</option>
        <option value="Summer">Summer</option>
    </select><br><br>

    <button type="submit">Enroll Student</button>
</form>

<?php include '../includes/footer.php'; ?>