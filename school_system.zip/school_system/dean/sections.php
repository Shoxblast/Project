<?php
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/functions.php';   // ← This was missing
requireDean();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cn_number   = generateControlNumber($pdo);
    $classNumber = "CN-" . $cn_number;

    $stmt = $pdo->prepare("
        INSERT INTO class_sections 
        (CN_Number, ClassNumber, SubjectID, FacultyID, DepartmentID, AcademicYearID, 
         Semester, Schedule, Room, MaxStudents, CreatedBy) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $success = $stmt->execute([
        $cn_number,
        $classNumber,
        $_POST['subject_id'],
        $_POST['faculty_id'] ?? null,
        $_SESSION['department_id'],
        $_POST['academic_year_id'],
        $_POST['semester'],
        trim($_POST['schedule']),
        trim($_POST['room']),
        (int)$_POST['max_students'],
        $_SESSION['user_id']
    ]);

    if ($success) {
        $_SESSION['success'] = "✅ Class Section Created!<br><strong>Control Number: $classNumber</strong>";
    } else {
        $_SESSION['error'] = "Failed to create class section.";
    }
    header("Location: sections.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>🔢 Create New Class Section</h2>
<?php displayMessage(); ?>

<form method="POST">
    <p><strong>Auto Generated CN:</strong> <b>CN-<?php echo generateControlNumber($pdo); ?></b></p>

    <select name="subject_id" required>
        <option value="">Select Subject</option>
        <?php
        $stmt = $pdo->prepare("SELECT SubjectID, SubjectCode, SubjectName FROM subjects WHERE DepartmentID = ?");
        $stmt->execute([$_SESSION['department_id']]);
        while ($row = $stmt->fetch()) {
            echo "<option value='{$row['SubjectID']}'>{$row['SubjectCode']} - {$row['SubjectName']}</option>";
        }
        ?>
    </select><br><br>

    <select name="faculty_id">
        <option value="">Assign Faculty (Optional)</option>
        <?php
        $stmt = $pdo->prepare("SELECT f.FacultyID, u.FirstName, u.LastName 
                               FROM faculty f JOIN users u ON f.UserID = u.UserID 
                               WHERE u.DepartmentID = ?");
        $stmt->execute([$_SESSION['department_id']]);
        while ($row = $stmt->fetch()) {
            echo "<option value='{$row['FacultyID']}'>{$row['FirstName']} {$row['LastName']}</option>";
        }
        ?>
    </select><br><br>

    <select name="academic_year_id" required>
        <?php
        $years = $pdo->query("SELECT AcademicYearID, YearName FROM academic_years ORDER BY YearName DESC")->fetchAll();
        foreach ($years as $y) {
            echo "<option value='{$y['AcademicYearID']}'>{$y['YearName']}</option>";
        }
        ?>
    </select><br><br>

    <select name="semester" required>
        <option value="1st">1st Semester</option>
        <option value="2nd">2nd Semester</option>
        <option value="Summer">Summer</option>
    </select><br><br>

    <input type="text" name="schedule" placeholder="Schedule (e.g. MWF 8:00-9:30)" style="width:350px;">
    <input type="text" name="room" placeholder="Room">
    <input type="number" name="max_students" value="40" min="1">

    <button type="submit">Create Class Section</button>
</form>

<?php include '../includes/footer.php'; ?>