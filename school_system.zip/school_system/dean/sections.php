<?php
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/functions.php';
requireDean();

$dept_id = $_SESSION['department_id'];

// Auto-create academic year if none exists
if ($pdo->query("SELECT COUNT(*) FROM academic_years")->fetchColumn() == 0) {
    $pdo->query("INSERT INTO academic_years (YearName, StartDate, EndDate, IsActive) 
                 VALUES ('2026-2027', '2026-06-01', '2027-05-31', 1)");
}

// ======================
// HANDLE DELETE
// ======================
if (isset($_GET['delete'])) {
    $sectionID = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM class_sections WHERE SectionID = ? AND DepartmentID = ?");
    if ($stmt->execute([$sectionID, $dept_id])) {
        $_SESSION['success'] = "✅ Class section deleted successfully!";
    } else {
        $_SESSION['error'] = "Failed to delete section.";
    }
    header("Location: sections.php");
    exit();
}

// ======================
// HANDLE CREATE
// ======================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cn_number   = generateControlNumber($pdo);
    $classNumber = "CN-" . $cn_number;

    $stmt = $pdo->prepare("
        INSERT INTO class_sections 
        (CN_Number, ClassNumber, SubjectID, FacultyID, DepartmentID, AcademicYearID, 
         Semester, Schedule, Room, MaxStudents, CreatedBy) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $success = $stmt->execute([
        $cn_number,
        $classNumber,
        $_POST['subject_id'],
        $_POST['faculty_id'] ?? null,
        $dept_id,
        $_POST['academic_year_id'],
        $_POST['semester'],
        trim($_POST['schedule'] ?? ''),
        trim($_POST['room'] ?? ''),
        (int)$_POST['max_students'],
        $_SESSION['user_id']
    ]);

    if ($success) {
        $_SESSION['success'] = "✅ Class Section Created Successfully!<br><strong>Control Number: $classNumber</strong>";
    } else {
        $_SESSION['error'] = "Failed to create class section.";
    }
    header("Location: sections.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>🔢 Manage Class Sections</h2>
<?php displayMessage(); ?>

<!-- ====================== CREATE FORM ====================== -->
<form method="POST" style="max-width: 950px; background:#f8fafc; padding:25px; border-radius:10px;">
    <p><strong>Auto Generated CN:</strong> <b>CN-<?php echo generateControlNumber($pdo); ?></b></p>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        
        <div>
            <label><strong>Select Subject</strong></label><br>
            <select name="subject_id" required style="width:100%; padding:12px;">
                <option value="">-- Select Subject --</option>
                <?php
                $stmt = $pdo->prepare("SELECT SubjectID, SubjectCode, SubjectName FROM subjects WHERE DepartmentID = ? ORDER BY SubjectCode");
                $stmt->execute([$dept_id]);
                while ($row = $stmt->fetch()) {
                    echo "<option value='{$row['SubjectID']}'>{$row['SubjectCode']} - {$row['SubjectName']}</option>";
                }
                ?>
            </select>
        </div>

        <div>
            <label><strong>Assign Faculty (Optional)</strong></label><br>
            <select name="faculty_id" style="width:100%; padding:12px;">
                <option value="">-- No Faculty Assigned Yet --</option>
                <?php
                $stmt = $pdo->prepare("SELECT f.FacultyID, CONCAT(u.FirstName,' ',u.LastName) as name 
                                       FROM faculty f JOIN users u ON f.UserID = u.UserID 
                                       WHERE u.DepartmentID = ?");
                $stmt->execute([$dept_id]);
                while ($row = $stmt->fetch()) {
                    echo "<option value='{$row['FacultyID']}'>{$row['name']}</option>";
                }
                ?>
            </select>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px;">
        <div>
            <label><strong>Academic Year</strong></label><br>
            <select name="academic_year_id" required style="width:100%; padding:12px;">
                <?php
                $years = $pdo->query("SELECT AcademicYearID, YearName FROM academic_years ORDER BY YearName DESC")->fetchAll();
                foreach ($years as $y) {
                    echo "<option value='{$y['AcademicYearID']}'>{$y['YearName']}</option>";
                }
                ?>
            </select>
        </div>

        <div>
            <label><strong>Semester</strong></label><br>
            <select name="semester" required style="width:100%; padding:12px;">
                <option value="1st">1st Semester</option>
                <option value="2nd">2nd Semester</option>
                <option value="Summer">Summer</option>
            </select>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 2fr 1fr 120px; gap: 15px; margin-top: 15px;">
        <div>
            <label><strong>Schedule</strong></label><br>
            <input type="text" name="schedule" placeholder="e.g. MWF 8:00-9:30 AM" style="width:100%; padding:12px;">
        </div>
        <div>
            <label><strong>Room</strong></label><br>
            <input type="text" name="room" placeholder="Room 101" style="width:100%; padding:12px;">
        </div>
        <div>
            <label><strong>Max Students</strong></label><br>
            <input type="number" name="max_students" value="40" min="1" style="width:100%; padding:12px;">
        </div>
    </div>

    <br>
    <button type="submit" style="padding:14px 32px; font-size:16px;">Create Class Section</button>
</form>

<!-- ====================== EXISTING SECTIONS ====================== -->
<h3 style="margin-top:40px;">Existing Class Sections</h3>

<table border="1" cellpadding="12" style="width:100%; border-collapse:collapse;">
    <tr>
        <th>CN</th>
        <th>Subject</th>
        <th>Faculty</th>
        <th>Schedule</th>
        <th>Room</th>
        <th>Semester</th>
        <th>Max Students</th>
        <th>Actions</th>
    </tr>
    <?php
    $stmt = $pdo->prepare("
        SELECT cs.*, s.SubjectCode, s.SubjectName,
               CONCAT(u.FirstName, ' ', u.LastName) as FacultyName,
               ay.YearName
        FROM class_sections cs
        JOIN subjects s ON cs.SubjectID = s.SubjectID
        LEFT JOIN faculty f ON cs.FacultyID = f.FacultyID
        LEFT JOIN users u ON f.UserID = u.UserID
        JOIN academic_years ay ON cs.AcademicYearID = ay.AcademicYearID
        WHERE cs.DepartmentID = ?
        ORDER BY cs.ClassNumber DESC
    ");
    $stmt->execute([$dept_id]);
    $sections = $stmt->fetchAll();

    if (count($sections) > 0):
        foreach ($sections as $sec):
    ?>
    <tr>
        <td><strong><?= htmlspecialchars($sec['ClassNumber']) ?></strong></td>
        <td><?= htmlspecialchars($sec['SubjectCode']) ?> - <?= htmlspecialchars($sec['SubjectName']) ?></td>
        <td><?= htmlspecialchars($sec['FacultyName'] ?? 'Not Assigned') ?></td>
        <td><?= htmlspecialchars($sec['Schedule'] ?? 'TBA') ?></td>
        <td><?= htmlspecialchars($sec['Room'] ?? 'TBA') ?></td>
        <td><?= $sec['Semester'] ?></td>
        <td align="center"><?= $sec['MaxStudents'] ?></td>
        <td>
            <a href="?delete=<?= $sec['SectionID'] ?>" 
               onclick="return confirm('Delete this class section? This action cannot be undone.')" 
               style="color:red;">Delete</a>
        </td>
    </tr>
    <?php endforeach; 
    else: ?>
    <tr><td colspan="8" style="text-align:center; padding:30px;">No class sections created yet.</td></tr>
    <?php endif; ?>
</table>

<?php include '../includes/footer.php'; ?>