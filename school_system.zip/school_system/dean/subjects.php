<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $code = strtoupper(trim($_POST['subject_code']));
    $name = trim($_POST['subject_name']);
    $units = (int)$_POST['units'];
    $lecture = (int)$_POST['lecture_hours'];
    $lab = (int)$_POST['lab_hours'];

    $stmt = $pdo->prepare("
        INSERT INTO subjects (SubjectCode, SubjectName, Units, LectureHours, LabHours, DepartmentID, CreatedBy) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    if ($stmt->execute([$code, $name, $units, $lecture, $lab, $_SESSION['department_id'], $_SESSION['user_id']])) {
        $_SESSION['success'] = "Subject created successfully!";
    } else {
        $_SESSION['error'] = "Failed to create subject.";
    }
    header("Location: subjects.php");
    exit();
}

include '../includes/dean_header.php'; 
?>

<h2>📖 Manage Subjects</h2>
<?php displayMessage(); ?>

<form method="POST">
    <input type="text" name="subject_code" placeholder="Subject Code (e.g. IT101)" required>
    <input type="text" name="subject_name" placeholder="Subject Name" required style="width:400px;">
    
    <input type="number" name="units" placeholder="Units" value="3" style="width:80px;">
    <input type="number" name="lecture_hours" placeholder="Lecture Hours" value="3" style="width:120px;">
    <input type="number" name="lab_hours" placeholder="Lab Hours" value="0" style="width:100px;">
    
    <button type="submit">Create Subject</button>
</form>

<hr>
<h3>Existing Subjects (<?= $_SESSION['department_id'] ? $pdo->query("SELECT COUNT(*) FROM subjects WHERE DepartmentID = ".$_SESSION['department_id'])->fetchColumn() : 0 ?>)</h3>

<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>Code</th>
        <th>Subject Name</th>
        <th>Units</th>
        <th>Lec</th>
        <th>Lab</th>
    </tr>
    <?php
    $stmt = $pdo->prepare("SELECT * FROM subjects WHERE DepartmentID = ? ORDER BY SubjectCode");
    $stmt->execute([$_SESSION['department_id']]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td><strong>{$row['SubjectCode']}</strong></td>
                <td>{$row['SubjectName']}</td>
                <td align='center'>{$row['Units']}</td>
                <td align='center'>{$row['LectureHours']}</td>
                <td align='center'>{$row['LabHours']}</td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>