<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

$dept_id = $_SESSION['department_id'];

// Handle Create
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_subject'])) {
    $code = strtoupper(trim($_POST['subject_code']));
    $name = trim($_POST['subject_name']);
    $units = (int)$_POST['units'];
    $lec = (int)$_POST['lecture_hours'];
    $lab = (int)$_POST['lab_hours'];

    $stmt = $pdo->prepare("
        INSERT INTO subjects (SubjectCode, SubjectName, Units, LectureHours, LabHours, DepartmentID, CreatedBy) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    if ($stmt->execute([$code, $name, $units, $lec, $lab, $dept_id, $_SESSION['user_id']])) {
        $_SESSION['success'] = "Subject created successfully!";
    } else {
        $_SESSION['error'] = "Failed to create subject (code may already exist).";
    }
    header("Location: subjects.php");
    exit();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM subjects WHERE SubjectID = ? AND DepartmentID = ?");
    if ($stmt->execute([$id, $dept_id])) {
        $_SESSION['success'] = "Subject deleted successfully.";
    }
    header("Location: subjects.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>📖 Manage Subjects</h2>
<?php displayMessage(); ?>

<!-- Create Form -->
<form method="POST" style="margin-bottom: 30px;">
    <input type="text" name="subject_code" placeholder="Subject Code (e.g. IT101)" required>
    <input type="text" name="subject_name" placeholder="Subject Name" required style="width:400px;">
    
    <input type="number" name="units" value="3" style="width:80px;">
    <input type="number" name="lecture_hours" value="3" style="width:100px;">
    <input type="number" name="lab_hours" value="0" style="width:100px;">
    
    <button type="submit" name="add_subject">Create Subject</button>
</form>

<h3>Existing Subjects (<?= $pdo->query("SELECT COUNT(*) FROM subjects WHERE DepartmentID = $dept_id")->fetchColumn() ?>)</h3>

<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>Code</th>
        <th>Subject Name</th>
        <th>Units</th>
        <th>Lec</th>
        <th>Lab</th>
        <th>Actions</th>
    </tr>
    <?php
    $stmt = $pdo->prepare("SELECT * FROM subjects WHERE DepartmentID = ? ORDER BY SubjectCode");
    $stmt->execute([$dept_id]);
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td><strong>{$row['SubjectCode']}</strong></td>
                <td>{$row['SubjectName']}</td>
                <td align='center'>{$row['Units']}</td>
                <td align='center'>{$row['LectureHours']}</td>
                <td align='center'>{$row['LabHours']}</td>
                <td>
                    <a href='edit_subject.php?id={$row['SubjectID']}'>Edit</a> | 
                    <a href='?delete={$row['SubjectID']}' onclick=\"return confirm('Delete this subject?')\">Delete</a>
                </td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>