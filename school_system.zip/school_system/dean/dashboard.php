<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/header.php';

$page_title = "Dean Dashboard";
requireDean();
?>

<h1>Welcome back, <?= htmlspecialchars($_SESSION['fullname']) ?> 👋</h1>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px; margin: 25px 0;">

    <?php
    $dept_id = $_SESSION['department_id'] ?? 0;

    $stats = [
        'Courses' => $pdo->query("SELECT COUNT(*) FROM courses WHERE DepartmentID = $dept_id")->fetchColumn(),
        'Subjects' => $pdo->query("SELECT COUNT(*) FROM subjects WHERE DepartmentID = $dept_id")->fetchColumn(),
        'Class Sections' => $pdo->query("SELECT COUNT(*) FROM class_sections WHERE DepartmentID = $dept_id")->fetchColumn(),
        'Faculty' => $pdo->query("SELECT COUNT(*) FROM faculty f JOIN users u ON f.UserID = u.UserID WHERE u.DepartmentID = $dept_id")->fetchColumn(),
        'Students' => $pdo->query("SELECT COUNT(*) FROM students s JOIN users u ON s.UserID = u.UserID WHERE u.DepartmentID = $dept_id")->fetchColumn()
    ];

    foreach ($stats as $label => $count):
    ?>
        <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h2 style="margin:0; color:#1e40af;"><?= number_format($count) ?></h2>
            <p style="margin:5px 0 0 0;"><?= $label ?></p>
        </div>
    <?php endforeach; ?>
</div>

<h3>Quick Actions</h3>
<ul style="font-size: 18px; line-height: 2;">
    <li><a href="subjects.php">📖 Manage Subjects</a></li>
    <li><a href="sections.php">🔢 Create Class Sections</a></li>
    <li><a href="faculty.php">👨‍🏫 Manage Faculty</a></li>
    <li><a href="students.php">👨‍🎓 Manage Students</a></li>
    <li><a href="courses.php">📚 Manage Courses</a></li>
</ul>

<?php include '../includes/footer.php'; ?>