<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireDean();

$page_title = "Manage Academic Years";

// ====================== EDIT ACADEMIC YEAR ======================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_year'])) {
    $id         = (int)$_POST['academic_year_id'];
    $yearName   = trim($_POST['year_name']);
    $startDate  = $_POST['start_date'];
    $endDate    = $_POST['end_date'];
    $isActive   = isset($_POST['is_active']) ? 1 : 0;

    try {
        if ($isActive) {
            $pdo->prepare("UPDATE academic_years SET IsActive = 0")->execute();
        }

        $stmt = $pdo->prepare("
            UPDATE academic_years 
            SET YearName = ?, StartDate = ?, EndDate = ?, IsActive = ? 
            WHERE AcademicYearID = ?
        ");
        $stmt->execute([$yearName, $startDate, $endDate, $isActive, $id]);
        
        $_SESSION['success'] = "✅ Academic Year updated successfully!";
    } catch (Exception $e) {
        $_SESSION['error'] = "Failed to update academic year.";
    }
    header("Location: academic_years.php");
    exit();
}

// ====================== ADD NEW ======================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_year'])) {
    $yearName   = trim($_POST['year_name']);
    $startDate  = $_POST['start_date'];
    $endDate    = $_POST['end_date'];
    $isActive   = isset($_POST['is_active']) ? 1 : 0;

    try {
        if ($isActive) {
            $pdo->prepare("UPDATE academic_years SET IsActive = 0")->execute();
        }

        $stmt = $pdo->prepare("
            INSERT INTO academic_years (YearName, StartDate, EndDate, IsActive) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$yearName, $startDate, $endDate, $isActive]);
        
        $_SESSION['success'] = "✅ Academic Year created successfully!";
    } catch (Exception $e) {
        $_SESSION['error'] = "Failed to create academic year.";
    }
    header("Location: academic_years.php");
    exit();
}

// Set Active
if (isset($_GET['set_active'])) {
    $id = (int)$_GET['set_active'];
    $pdo->prepare("UPDATE academic_years SET IsActive = 0")->execute();
    $pdo->prepare("UPDATE academic_years SET IsActive = 1 WHERE AcademicYearID = ?")->execute([$id]);
    $_SESSION['success'] = "✅ Academic Year activated.";
    header("Location: academic_years.php");
    exit();
}

// Delete (only inactive)
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM academic_years WHERE AcademicYearID = ? AND IsActive = 0")->execute([$id]);
    $_SESSION['success'] = "✅ Academic Year deleted.";
    header("Location: academic_years.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>📅 Manage Academic Years</h2>
<?php displayMessage(); ?>

<!-- Add / Edit Form -->
<h3><?= isset($_GET['edit']) ? 'Edit Academic Year' : 'Add New Academic Year' ?></h3>
<form method="POST" style="background:#f8fafc; padding:25px; border-radius:10px; margin-bottom:30px;">
    <?php if (isset($_GET['edit'])): 
        $editID = (int)$_GET['edit'];
        $stmt = $pdo->prepare("SELECT * FROM academic_years WHERE AcademicYearID = ?");
        $stmt->execute([$editID]);
        $editing = $stmt->fetch();
    ?>
        <input type="hidden" name="academic_year_id" value="<?= $editing['AcademicYearID'] ?>">
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 150px; gap: 15px; align-items:end;">
        <div>
            <label>Year Name (e.g. 2026-2027)</label><br>
            <input type="text" name="year_name" value="<?= htmlspecialchars($editing['YearName'] ?? '') ?>" required style="width:100%; padding:12px;">
        </div>
        <div>
            <label>Start Date</label><br>
            <input type="date" name="start_date" value="<?= $editing['StartDate'] ?? '' ?>" required style="width:100%; padding:12px;">
        </div>
        <div>
            <label>End Date</label><br>
            <input type="date" name="end_date" value="<?= $editing['EndDate'] ?? '' ?>" required style="width:100%; padding:12px;">
        </div>
        <div>
            <label><input type="checkbox" name="is_active" <?= ($editing['IsActive'] ?? 0) ? 'checked' : '' ?>> Set as Active</label><br>
            <button type="submit" name="<?= isset($_GET['edit']) ? 'edit_year' : 'add_year' ?>" style="padding:12px 25px;">
                <?= isset($_GET['edit']) ? 'Update Year' : 'Create Year' ?>
            </button>
        </div>
    </div>
</form>

<!-- Academic Years List -->
<h3>Academic Years Overview</h3>
<table border="1" cellpadding="12" style="width:100%;">
    <tr>
        <th>Year Name</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>Students</th>
        <th>Class Sections</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <?php
    $stmt = $pdo->query("
        SELECT ay.*, 
               (SELECT COUNT(*) FROM enrollments e WHERE e.AcademicYearID = ay.AcademicYearID) as total_students,
               (SELECT COUNT(*) FROM class_sections cs WHERE cs.AcademicYearID = ay.AcademicYearID) as total_sections
        FROM academic_years ay 
        ORDER BY ay.YearName DESC
    ");
    while ($row = $stmt->fetch()) {
        $status = $row['IsActive'] ? '<strong style="color:green;">Active</strong>' : 'Inactive';
        $activeBtn = $row['IsActive'] ? '' : "<a href='?set_active={$row['AcademicYearID']}'>Activate</a>";
    ?>
    <tr>
        <td><strong><?= htmlspecialchars($row['YearName']) ?></strong></td>
        <td><?= $row['StartDate'] ?></td>
        <td><?= $row['EndDate'] ?></td>
        <td align="center"><strong><?= number_format($row['total_students']) ?></strong></td>
        <td align="center"><strong><?= number_format($row['total_sections']) ?></strong></td>
        <td><?= $status ?></td>
        <td>
            <a href="?edit=<?= $row['AcademicYearID'] ?>">Edit</a>
            <?= $activeBtn ?>
            <?php if (!$row['IsActive']): ?>
                | <a href="?delete=<?= $row['AcademicYearID'] ?>" onclick="return confirm('Delete this academic year?')" style="color:red;">Delete</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php } ?>
</table>

<?php include '../includes/footer.php'; ?>