<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/header.php';

$page_title = "Faculty Dashboard";
requireFaculty();

$facultyID = $_SESSION['faculty_id'] ?? null;

// Get Faculty ID if not set
if (!$facultyID) {
    $stmt = $pdo->prepare("SELECT FacultyID FROM faculty WHERE UserID = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $_SESSION['faculty_id'] = $stmt->fetchColumn();
    $facultyID = $_SESSION['faculty_id'];
}
?>

<h1>Welcome, <?= htmlspecialchars($_SESSION['fullname']) ?> 👋</h1>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin: 30px 0;">
    <?php
    $classCount = $pdo->query("SELECT COUNT(*) FROM class_sections WHERE FacultyID = $facultyID")->fetchColumn();
    $studentCount = $pdo->query("
        SELECT COUNT(DISTINCT e.StudentID) 
        FROM enrollments e 
        JOIN class_sections cs ON e.SectionID = cs.SectionID 
        WHERE cs.FacultyID = $facultyID
    ")->fetchColumn();
    ?>
    <div style="background:white; padding:25px; border-radius:8px; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
        <h3>My Classes</h3>
        <h2><?= number_format($classCount) ?></h2>
    </div>
    <div style="background:white; padding:25px; border-radius:8px; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
        <h3>Students Taught</h3>
        <h2><?= number_format($studentCount) ?></h2>
    </div>
</div>

<h3>Quick Links</h3>
<ul style="font-size:18px;">
    <li><a href="my_classes.php">📋 View My Classes</a></li>
    <li><a href="grade_entry.php">📝 Enter Grades</a></li>
</ul>

<?php include '../includes/footer.php'; ?>