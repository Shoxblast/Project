<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFaculty();

$facultyID = $_SESSION['faculty_id'] ?? null;

$stmt = $pdo->prepare("
    SELECT cs.ClassNumber, s.SubjectCode, s.SubjectName, cs.Schedule, cs.Room,
           ay.YearName, cs.Semester
    FROM class_sections cs
    JOIN subjects s ON cs.SubjectID = s.SubjectID
    JOIN academic_years ay ON cs.AcademicYearID = ay.AcademicYearID
    WHERE cs.FacultyID = ?
    ORDER BY ay.YearName DESC, cs.Semester
");
$stmt->execute([$facultyID]);
$classes = $stmt->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<h1>📚 My Classes</h1>

<?php if (count($classes) > 0): ?>
    <table border="1" cellpadding="12" style="width:100%;">
        <tr>
            <th>CN</th>
            <th>Subject</th>
            <th>Schedule</th>
            <th>Room</th>
            <th>Academic Year</th>
            <th>Semester</th>
            <th>Action</th>
        </tr>
        <?php foreach ($classes as $c): ?>
        <tr>
            <td><?= htmlspecialchars($c['ClassNumber']) ?></td>
            <td><strong><?= htmlspecialchars($c['SubjectCode']) ?></strong> - <?= htmlspecialchars($c['SubjectName']) ?></td>
            <td><?= htmlspecialchars($c['Schedule'] ?? 'TBA') ?></td>
            <td><?= htmlspecialchars($c['Room'] ?? 'TBA') ?></td>
            <td><?= htmlspecialchars($c['YearName']) ?></td>
            <td><?= $c['Semester'] ?></td>
            <td><a href="grade_entry.php?class_id=<?= $c['ClassNumber'] ?>">Enter Grades</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
<?php else: ?>
    <p>You are not assigned to any class sections yet.</p>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>