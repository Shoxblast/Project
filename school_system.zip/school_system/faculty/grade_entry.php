<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFaculty();

$facultyID = $_SESSION['faculty_id'];

// Get class sections taught by this faculty
$stmt = $pdo->prepare("
    SELECT cs.SectionID, cs.ClassNumber, s.SubjectCode, s.SubjectName
    FROM class_sections cs
    JOIN subjects s ON cs.SubjectID = s.SubjectID
    WHERE cs.FacultyID = ?
");
$stmt->execute([$facultyID]);
$myClasses = $stmt->fetchAll();

$selectedSection = $_GET['section_id'] ?? null;

// Fetch students in selected class
$students = [];
if ($selectedSection) {
    $stmt = $pdo->prepare("
        SELECT e.EnrollmentID, s.StudentNumber, u.FirstName, u.LastName,
               g.Midterm, g.Final, g.FinalGrade, g.Remarks
        FROM enrollments e
        JOIN students s ON e.StudentID = s.StudentID
        JOIN users u ON s.UserID = u.UserID
        LEFT JOIN grades g ON e.EnrollmentID = g.EnrollmentID
        WHERE e.SectionID = ? AND e.Status = 'Enrolled'
        ORDER BY s.StudentNumber
    ");
    $stmt->execute([$selectedSection]);
    $students = $stmt->fetchAll();
}
?>

<?php include '../includes/header.php'; ?>

<h1>📝 Grade Entry</h1>

<select onchange="window.location='grade_entry.php?section_id='+this.value" style="padding:10px; width:400px;">
    <option value="">Select Class Section</option>
    <?php foreach ($myClasses as $c): ?>
    <option value="<?= $c['SectionID'] ?>" <?= $selectedSection == $c['SectionID'] ? 'selected' : '' ?>>
        <?= $c['ClassNumber'] ?> - <?= $c['SubjectCode'] ?> <?= $c['SubjectName'] ?>
    </option>
    <?php endforeach; ?>
</select>

<?php if ($selectedSection && count($students) > 0): ?>
    <form method="POST" action="save_grades.php">
        <input type="hidden" name="section_id" value="<?= $selectedSection ?>">
        <table border="1" cellpadding="10" style="width:100%; margin-top:20px;">
            <tr>
                <th>Student No.</th>
                <th>Student Name</th>
                <th>Midterm</th>
                <th>Final</th>
                <th>Final Grade</th>
                <th>Remarks</th>
            </tr>
            <?php foreach ($students as $row): ?>
            <tr>
                <td><?= $row['StudentNumber'] ?></td>
                <td><?= $row['FirstName'] . ' ' . $row['LastName'] ?></td>
                <td><input type="number" step="0.01" name="midterm[<?= $row['EnrollmentID'] ?>]" value="<?= $row['Midterm'] ?>" style="width:80px;"></td>
                <td><input type="number" step="0.01" name="final[<?= $row['EnrollmentID'] ?>]" value="<?= $row['Final'] ?>" style="width:80px;"></td>
                <td><?= number_format($row['FinalGrade'] ?? 0, 2) ?></td>
                <td><?= htmlspecialchars($row['Remarks'] ?? '') ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <br>
        <button type="submit" style="padding:12px 30px;">Save Grades</button>
    </form>
<?php elseif ($selectedSection): ?>
    <p>No students enrolled in this class yet.</p>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>