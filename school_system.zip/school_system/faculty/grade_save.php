<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFaculty();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: grade_entry.php");
    exit();
}

$sectionID = (int)$_POST['section_id'];
$facultyID = $_SESSION['faculty_id'] ?? null;

try {
    $pdo->beginTransaction();

    foreach ($_POST['midterm'] as $enrollmentID => $midterm) {
        $final = $_POST['final'][$enrollmentID] ?? null;
        $enrollmentID = (int)$enrollmentID;

        // Get Subject & Academic Info
        $stmt = $pdo->prepare("
            SELECT SubjectID, AcademicYearID, Semester 
            FROM class_sections WHERE SectionID = ?
        ");
        $stmt->execute([$sectionID]);
        $info = $stmt->fetch();

        // Check if grade record exists
        $check = $pdo->prepare("SELECT GradeID FROM grades WHERE EnrollmentID = ?");
        $check->execute([$enrollmentID]);
        $exists = $check->fetch();

        if ($exists) {
            // Update
            $stmt = $pdo->prepare("
                UPDATE grades 
                SET Midterm = ?, Final = ?, GradedBy = ?, UpdatedAt = NOW()
                WHERE EnrollmentID = ?
            ");
            $stmt->execute([$midterm, $final, $_SESSION['user_id'], $enrollmentID]);
        } else {
            // Insert new
            $stmt = $pdo->prepare("
                INSERT INTO grades 
                (EnrollmentID, SubjectID, AcademicYearID, Semester, Midterm, Final, GradedBy) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $enrollmentID, 
                $info['SubjectID'], 
                $info['AcademicYearID'], 
                $info['Semester'], 
                $midterm, 
                $final, 
                $_SESSION['user_id']
            ]);
        }
    }

    $pdo->commit();
    $_SESSION['success'] = "✅ Grades saved successfully!";

} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = "Failed to save grades: " . $e->getMessage();
}

header("Location: grade_entry.php?section_id=$sectionID");
exit();
?>