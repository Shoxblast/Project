<?php
// get_provinces.php
require_once '../config/db.php';
header('Content-Type: application/json');

if (isset($_GET['region'])) {
    $region = trim($_GET['region']);

    try {
        $stmt = $pdo->prepare("
            SELECT DISTINCT PROVINCE 
            FROM cities 
            WHERE REGION = ? 
            ORDER BY PROVINCE ASC
        ");
        $stmt->execute([$region]);

        $provinces = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo json_encode($provinces);
    } catch (Exception $e) {
        echo json_encode([]);
    }
} else {
    echo json_encode([]);
}
?>