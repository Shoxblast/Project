<?php
// get_cities.php
require_once '../config/db.php';
header('Content-Type: application/json');

if (isset($_GET['province'])) {
    $province = trim($_GET['province']);

    try {
        $stmt = $pdo->prepare("
            SELECT DISTINCT CITIES_MUNICIPALITIES 
            FROM cities 
            WHERE PROVINCE = ? 
            ORDER BY CITIES_MUNICIPALITIES ASC
        ");
        $stmt->execute([$province]);

        $cities = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo json_encode($cities);
    } catch (Exception $e) {
        echo json_encode([]);
    }
} else {
    echo json_encode([]);
}
?>