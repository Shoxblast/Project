<?php
// get_zipcode.php
require_once '../config/db.php';
header('Content-Type: application/json');

if (isset($_GET['city'])) {
    $city = trim($_GET['city']);

    try {
        $stmt = $pdo->prepare("
            SELECT ZIPCODE 
            FROM cities 
            WHERE CITIES_MUNICIPALITIES = ? 
            LIMIT 1
        ");
        $stmt->execute([$city]);

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'zipcode' => $result ? trim($result['ZIPCODE']) : ''
        ]);
    } catch (Exception $e) {
        echo json_encode(['zipcode' => '']);
    }
} else {
    echo json_encode(['zipcode' => '']);
}
?>