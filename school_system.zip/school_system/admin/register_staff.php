<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireAdmin();   // Or requireDean() if you want Deans to register staff

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username   = trim($_POST['username']);
    $password   = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $firstName  = trim($_POST['first_name']);
    $lastName   = trim($_POST['last_name']);
    $email      = trim($_POST['email']);
    $phone      = trim($_POST['phone']);
    $role       = $_POST['role'];
    $departmentID = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;

    $stmt = $pdo->prepare("
        INSERT INTO users 
        (Username, PasswordHash, Role, FirstName, LastName, Email, Phone, DepartmentID) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");

    if ($stmt->execute([$username, $password, $role, $firstName, $lastName, $email, $phone, $departmentID])) {
        $newUserID = $pdo->lastInsertId();

        // Create additional records based on role
        if ($role === 'faculty') {
            $pdo->prepare("INSERT INTO faculty (UserID, Position) VALUES (?, ?)")->execute([$newUserID, $_POST['position'] ?? 'Instructor']);
        }

        $_SESSION['success'] = "Staff member ($role) registered successfully! Default password can be changed later.";
        header("Location: register_staff.php");
        exit();
    } else {
        $_SESSION['error'] = "Registration failed. Username or Email may already exist.";
    }
}

include '../includes/admin_header.php';   // We'll create this
?>

<h2>Register New Staff Member</h2>
<?php displayMessage(); ?>

<form method="POST">
    <input type="text" name="username" placeholder="Username" required><br><br>
    <input type="password" name="password" placeholder="Password" required><br><br>
    
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="last_name" placeholder="Last Name" required><br><br>
    
    <input type="email" name="email" placeholder="Email Address">
    <input type="text" name="phone" placeholder="Phone Number"><br><br>

    <label>Role:</label><br>
    <select name="role" required onchange="toggleFacultyFields(this)">
        <option value="dean">Dean</option>
        <option value="faculty">Faculty / Teacher</option>
        <option value="finance">Finance</option>
        <option value="cashier">Cashier</option>
        <option value="admin">Admin</option>
    </select><br><br>

    <div id="faculty_fields" style="display:none;">
        <input type="text" name="position" placeholder="Position (e.g. Professor, Instructor)"><br><br>
    </div>

    <select name="department_id">
        <option value="">No Department / School-wide</option>
        <?php
        $depts = $pdo->query("SELECT * FROM departments ORDER BY DepartmentName")->fetchAll();
        foreach ($depts as $d) {
            echo "<option value='{$d['DepartmentID']}'>{$d['DepartmentName']} ({$d['DepartmentAcronym']})</option>";
        }
        ?>
    </select><br><br>

    <button type="submit">Register Staff</button>
</form>

<script>
function toggleFacultyFields(select) {
    document.getElementById('faculty_fields').style.display = 
        select.value === 'faculty' ? 'block' : 'none';
}
</script>

<?php include '../includes/footer.php'; ?>