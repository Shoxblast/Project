<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireAdmin();   // Change to requireDean() if only Deans should register students

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentNumber = trim($_POST['student_number']);
    $firstName     = trim($_POST['first_name']);
    $lastName      = trim($_POST['last_name']);
    $email         = trim($_POST['email']);
    $phone         = trim($_POST['phone']);
    $dateOfBirth   = $_POST['date_of_birth'];
    $gender        = $_POST['gender'];
    $ethnicity     = trim($_POST['ethnicity']);
    $religion      = trim($_POST['religion']);
    $region        = trim($_POST['region']);
    $province      = trim($_POST['province']);   // Optional: you can store if needed
    $city          = trim($_POST['city']);
    $zipcode       = trim($_POST['zipcode']);
    $dialect       = trim($_POST['dialect']);
    $guardianName  = trim($_POST['guardian_name']);
    $guardianPhone = trim($_POST['guardian_phone']);
    $guardianEmail = trim($_POST['guardian_email']);
    $departmentID  = (int)$_POST['department_id'];

    $passwordHash = password_hash('password123', PASSWORD_DEFAULT); // Default password

    $pdo->beginTransaction();

    try {
        // 1. Create User Account
        $stmt = $pdo->prepare("
            INSERT INTO users 
            (Username, PasswordHash, Role, FirstName, LastName, Email, Phone, DepartmentID) 
            VALUES (?, ?, 'student', ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$studentNumber, $passwordHash, $firstName, $lastName, $email, $phone, $departmentID]);
        $userID = $pdo->lastInsertId();

        // 2. Create Student Record
        $stmt2 = $pdo->prepare("
            INSERT INTO students 
            (UserID, StudentNumber, DateOfBirth, Gender, Ethnicity, Religion, 
             Region, City, ZipCode, Dialect, GuardianName, GuardianPhone, GuardianEmail, Status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')
        ");
        $stmt2->execute([
            $userID, $studentNumber, $dateOfBirth, $gender, $ethnicity, $religion,
            $region, $city, $zipcode, $dialect, $guardianName, $guardianPhone, $guardianEmail
        ]);

        // 3. Create Student Account (Balance)
        $pdo->prepare("INSERT INTO student_accounts (StudentID, TotalBalance) VALUES (LAST_INSERT_ID(), 0)")->execute();

        $pdo->commit();

        $_SESSION['success'] = "✅ Student registered successfully!<br>
                                <strong>Student Number:</strong> $studentNumber<br>
                                <strong>Default Password:</strong> password123";

        header("Location: register_student.php");
        exit();

    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "❌ Registration failed: " . $e->getMessage();
    }
}

include '../includes/admin_header.php';
?>

<h2>🎓 Register New Student</h2>
<?php displayMessage(); ?>

<form method="POST" id="studentForm">
    <h3>Basic Information</h3>
    <input type="text" name="student_number" placeholder="Student Number (e.g. 2025-00001)" required><br><br>
    
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="last_name" placeholder="Last Name" required><br><br>

    <input type="email" name="email" placeholder="Email Address">
    <input type="text" name="phone" placeholder="Phone Number"><br><br>

    <label>Date of Birth:</label>
    <input type="date" name="date_of_birth" required><br><br>

    <label>Gender:</label>
    <select name="gender" required>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        <option value="Other">Other</option>
    </select><br><br>

    <h3>Personal & Cultural Info</h3>
    <select name="ethnicity">
        <option value="">Select Ethnicity</option>
        <?php
        $eth = $pdo->query("SELECT DISTINCT ethnicname FROM ethnicity ORDER BY ethnicname")->fetchAll();
        foreach ($eth as $e) echo "<option value='".htmlspecialchars($e['ethnicname'])."'>".htmlspecialchars($e['ethnicname'])."</option>";
        ?>
    </select>

    <select name="religion">
        <option value="">Select Religion</option>
        <?php
        $rel = $pdo->query("SELECT DISTINCT religion FROM religions ORDER BY religion")->fetchAll();
        foreach ($rel as $r) echo "<option value='".htmlspecialchars($r['religion'])."'>".htmlspecialchars($r['religion'])."</option>";
        ?>
    </select><br><br>

    <select name="dialect">
        <option value="">Select Dialect / Language</option>
        <?php
        $dia = $pdo->query("SELECT DISTINCT dialects FROM dialects ORDER BY dialects")->fetchAll();
        foreach ($dia as $d) echo "<option value='".htmlspecialchars($d['dialects'])."'>".htmlspecialchars($d['dialects'])."</option>";
        ?>
    </select><br><br>

    <h3>Address Information</h3>
    <select name="region" id="region" onchange="loadProvinces(this.value)" required>
        <option value="">-- Select Region --</option>
        <option value="REGIONXIII">Caraga (Region XIII)</option>
        <option value="ARMM">ARMM / BARMM</option>
        <option value="REGIONIX">Zamboanga Peninsula (IX)</option>
        <option value="REGIONX">Northern Mindanao (X)</option>
        <option value="REGIONXI">Davao Region (XI)</option>
        <option value="REGIONXII">SOCCSKSARGEN (XII)</option>
    </select><br><br>

    <select name="province" id="province" onchange="loadCities(this.value)" required>
        <option value="">-- Select Province --</option>
    </select><br><br>

    <select name="city" id="city" onchange="getZipCode(this.value)" required>
        <option value="">-- Select City/Municipality --</option>
    </select><br><br>

    <input type="text" name="zipcode" id="zipcode" placeholder="Zip Code" readonly><br><br>

    <input type="text" name="address" placeholder="Street / Barangay (Optional)" style="width:100%;"><br><br>

    <h3>Guardian Information</h3>
    <input type="text" name="guardian_name" placeholder="Guardian Full Name" required><br><br>
    <input type="text" name="guardian_phone" placeholder="Guardian Phone Number" required><br><br>
    <input type="email" name="guardian_email" placeholder="Guardian Email (Optional)"><br><br>

    <label>Department / Course:</label><br>
    <select name="department_id" required>
        <option value="">-- Select Department --</option>
        <?php
        $depts = $pdo->query("SELECT * FROM departments ORDER BY DepartmentName")->fetchAll();
        foreach ($depts as $d) {
            echo "<option value='{$d['DepartmentID']}'>{$d['DepartmentName']} ({$d['DepartmentAcronym']})</option>";
        }
        ?>
    </select><br><br>

    <button type="submit" style="padding:12px 30px; font-size:16px;">Register Student</button>
</form>

<?php include '../includes/footer.php'; ?>

<script>
// AJAX Functions for Location
function loadProvinces(region) {
    if (!region) return;
    fetch(`get_provinces.php?region=${encodeURIComponent(region)}`)
        .then(r => r.json())
        .then(data => {
            const sel = document.getElementById('province');
            sel.innerHTML = '<option value="">-- Select Province --</option>';
            data.forEach(p => {
                sel.innerHTML += `<option value="${p}">${p}</option>`;
            });
        });
}

function loadCities(province) {
    if (!province) return;
    fetch(`get_cities.php?province=${encodeURIComponent(province)}`)
        .then(r => r.json())
        .then(data => {
            const sel = document.getElementById('city');
            sel.innerHTML = '<option value="">-- Select City/Municipality --</option>';
            data.forEach(c => {
                sel.innerHTML += `<option value="${c}">${c}</option>`;
            });
        });
}

function getZipCode(city) {
    if (!city) return;
    fetch(`get_zipcode.php?city=${encodeURIComponent(city)}`)
        .then(r => r.json())
        .then(data => {
            document.getElementById('zipcode').value = data.zipcode || '';
        });
}
</script>