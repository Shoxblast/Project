<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/header.php'; 

$page_title = "Admin Dashboard";
requireAdmin();   // Only Admin can access
?>

<h1>⚙️ Admin Dashboard</h1>
<p>Welcome, <?= htmlspecialchars($_SESSION['fullname']) ?> (System Administrator)</p>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; margin: 30px 0;">

    <?php
    $totalUsers     = $pdo->query("SELECT COUNT(*) FROM users WHERE IsActive = 1")->fetchColumn();
    $totalStudents  = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $totalFaculty   = $pdo->query("SELECT COUNT(*) FROM faculty")->fetchColumn();
    $totalDepartments = $pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();
    $totalCourses   = $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
    $totalSections  = $pdo->query("SELECT COUNT(*) FROM class_sections")->fetchColumn();
    ?>

    <div style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1); text-align:center;">
        <h2 style="color:#1e40af; margin:0;"><?= number_format($totalUsers) ?></h2>
        <p><strong>Total Active Users</strong></p>
    </div>

    <div style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1); text-align:center;">
        <h2 style="color:#10b981; margin:0;"><?= number_format($totalStudents) ?></h2>
        <p><strong>Total Students</strong></p>
    </div>

    <div style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1); text-align:center;">
        <h2 style="color:#f59e0b; margin:0;"><?= number_format($totalFaculty) ?></h2>
        <p><strong>Total Faculty</strong></p>
    </div>

    <div style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1); text-align:center;">
        <h2 style="color:#8b5cf6; margin:0;"><?= number_format($totalDepartments) ?></h2>
        <p><strong>Departments</strong></p>
    </div>

    <div style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1); text-align:center;">
        <h2 style="color:#ec4899; margin:0;"><?= number_format($totalCourses) ?></h2>
        <p><strong>Courses</strong></p>
    </div>

    <div style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1); text-align:center;">
        <h2 style="color:#14b8a6; margin:0;"><?= number_format($totalSections) ?></h2>
        <p><strong>Class Sections</strong></p>
    </div>
</div>

<h3>Quick Actions</h3>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 15px;">
    <a href="register_staff.php" style="text-decoration:none;">
        <div style="background:white; padding:20px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
            👤 Register New Staff
        </div>
    </a>
    <a href="register_student.php" style="text-decoration:none;">
        <div style="background:white; padding:20px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
            🎓 Register New Student
        </div>
    </a>
    <a href="../change_password.php" style="text-decoration:none;">
        <div style="background:white; padding:20px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
            🔑 Change Password
        </div>
    </a>
</div>

<br>
<p><strong>System Status:</strong> All systems operational.</p>

<?php include '../includes/footer.php'; ?>