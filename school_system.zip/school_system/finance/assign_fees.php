<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFinance();

include '../includes/header.php'; 
$page_title = "Assign Fees to Student";

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentID = (int)$_POST['student_id'];

    if (!$studentID) {
        $_SESSION['error'] = "Please select a student.";
        header("Location: assign_fees.php");
        exit();
    }

    $pdo->beginTransaction();
    try {
        $totalAdded = 0;

        // Auto-calculate Tuition & Lab Fees (if requested)
        if (isset($_POST['auto_calculate'])) {
            $stmt = $pdo->prepare("
                SELECT SUM(s.Units) as total_units, SUM(s.LabHours) as total_lab 
                FROM enrollments e
                JOIN class_sections cs ON e.SectionID = cs.SectionID
                JOIN subjects s ON cs.SubjectID = s.SubjectID
                WHERE e.StudentID = ? AND e.Status = 'Enrolled'
            ");
            $stmt->execute([$studentID]);
            $stats = $stmt->fetch();

            $totalUnits = $stats['total_units'] ?? 0;
            $totalLab = $stats['total_lab'] ?? 0;

            // Tuition per unit
            $pdo->prepare("UPDATE student_accounts SET TotalBalance = TotalBalance + ? WHERE StudentID = ?")
                ->execute([$totalUnits * 1500, $studentID]);
            $totalAdded += $totalUnits * 1500;

            // Lab fee per hour
            if ($totalLab > 0) {
                $pdo->prepare("UPDATE student_accounts SET TotalBalance = TotalBalance + ? WHERE StudentID = ?")
                    ->execute([$totalLab * 300, $studentID]);
                $totalAdded += $totalLab * 300;
            }
        }

        // Add selected manual fees
        if (!empty($_POST['fee_ids'])) {
            $feeIds = $_POST['fee_ids'];
            $stmt = $pdo->prepare("SELECT Amount FROM fees WHERE FeeID = ?");
            foreach ($feeIds as $feeID) {
                $stmt->execute([$feeID]);
                $amount = $stmt->fetchColumn();
                if ($amount) {
                    $pdo->prepare("UPDATE student_accounts SET TotalBalance = TotalBalance + ? WHERE StudentID = ?")
                        ->execute([$amount, $studentID]);
                    $totalAdded += $amount;
                }
            }
        }

        $pdo->commit();
        $_SESSION['success'] = "✅ Fees assigned successfully! Total added: ₱" . number_format($totalAdded, 2);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to assign fees.";
    }

    header("Location: assign_fees.php?student_id=$studentID");
    exit();
}
?>

<h2>💰 Assign Fees to Student</h2>
<?php displayMessage(); ?>

<form method="POST">
    <label><strong>Select Student</strong></label><br>
    <select name="student_id" onchange="this.form.submit()" style="width:100%; padding:12px; margin:10px 0;">
        <option value="">-- Select Student --</option>
        <?php
        $students = $pdo->query("
            SELECT s.StudentID, s.StudentNumber, u.FirstName, u.LastName, 
                   COALESCE(sa.TotalBalance, 0) as Balance
            FROM students s 
            JOIN users u ON s.UserID = u.UserID 
            LEFT JOIN student_accounts sa ON s.StudentID = sa.StudentID
            ORDER BY s.StudentNumber
        ")->fetchAll();

        $selectedStudent = $_GET['student_id'] ?? '';
        foreach ($students as $s):
            $sel = ($s['StudentID'] == $selectedStudent) ? 'selected' : '';
        ?>
            <option value="<?= $s['StudentID'] ?>" <?= $sel ?>>
                <?= $s['StudentNumber'] ?> - <?= htmlspecialchars($s['FirstName'].' '.$s['LastName']) ?> 
                (₱<?= number_format($s['Balance'], 2) ?>)
            </option>
        <?php endforeach; ?>
    </select>

    <?php if ($selectedStudent): ?>
        <h3>Auto-Calculate Based on Enrolled Subjects</h3>
        <button type="submit" name="auto_calculate" value="1" style="padding:12px 25px; background:#10b981; color:white; border:none; border-radius:6px;">
            Calculate & Add Tuition + Lab Fees
        </button>

        <hr>
        <h3>Add Additional Fees</h3>
        <select name="fee_ids[]" multiple size="8" style="width:100%; padding:10px;">
            <?php
            $fees = $pdo->query("SELECT FeeID, FeeName, Amount, FeeType FROM fees WHERE IsActive = 1 ORDER BY FeeName")->fetchAll();
            foreach ($fees as $f):
            ?>
                <option value="<?= $f['FeeID'] ?>">
                    <?= htmlspecialchars($f['FeeName']) ?> — ₱<?= number_format($f['Amount'], 2) ?> (<?= $f['FeeType'] ?>)
                </option>
            <?php endforeach; ?>
        </select>
        <small><em>Hold Ctrl (or Cmd) to select multiple fees</em></small><br><br>
    <?php endif; ?>

    <button type="submit" style="padding:14px 30px; font-size:16px;">Assign Selected Fees</button>
</form>

<?php include '../includes/footer.php'; ?>