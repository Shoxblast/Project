<?php
require_once '../includes/session.php';
requireFinance();   // Custom function similar to requireDean()

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentID = $_POST['student_id'];
    $feeID     = $_POST['fee_id'];

    // Get fee amount
    $fee = $pdo->prepare("SELECT Amount FROM fees WHERE FeeID = ?")->execute([$feeID]);
    $amount = $pdo->fetchColumn();

    // Add to student balance
    $stmt = $pdo->prepare("UPDATE student_accounts SET TotalBalance = TotalBalance + ? WHERE StudentID = ?");
    $stmt->execute([$amount, $studentID]);

    $success = "Fee assigned successfully!";
}
?>