<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFinance();

include '../includes/header.php'; 
?>

<h2>💵 All Payments History</h2>

<table border="1" cellpadding="12" style="width:100%;">
    <tr>
        <th>Date</th>
        <th>Student</th>
        <th>Amount</th>
        <th>Method</th>
        <th>Reference</th>
        <th>Cashier</th>
        <th>Notes</th>
    </tr>
    <?php
    $stmt = $pdo->query("
        SELECT p.*, 
               CONCAT(su.FirstName, ' ', su.LastName) as StudentName,
               s.StudentNumber,
               CONCAT(cu.FirstName, ' ', cu.LastName) as CashierName
        FROM payments p
        JOIN students s ON p.StudentID = s.StudentID
        JOIN users su ON s.UserID = su.UserID
        JOIN users cu ON p.CashierID = cu.UserID
        ORDER BY p.PaymentDate DESC
    ");
    while ($row = $stmt->fetch()) {
        echo "<tr>
                <td>" . date('M d, Y h:i A', strtotime($row['PaymentDate'])) . "</td>
                <td>{$row['StudentNumber']} - {$row['StudentName']}</td>
                <td style='font-weight:bold;'>₱" . number_format($row['AmountPaid'], 2) . "</td>
                <td>{$row['PaymentMethod']}</td>
                <td>{$row['ReferenceNo']}</td>
                <td>{$row['CashierName']}</td>
                <td>" . htmlspecialchars($row['Notes'] ?? '-') . "</td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>