<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFinance();

include '../includes/finance_header.php'; 

// Handle Create Fee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_fee'])) {
    $feeName = trim($_POST['fee_name']);
    $amount  = (float)$_POST['amount'];
    $feeType = $_POST['fee_type'];

    $stmt = $pdo->prepare("INSERT INTO fees (FeeName, Amount, FeeType) VALUES (?, ?, ?)");
    if ($stmt->execute([$feeName, $amount, $feeType])) {
        $_SESSION['success'] = "Fee created successfully!";
    } else {
        $_SESSION['error'] = "Failed to create fee.";
    }
    header("Location: fees.php");
    exit();
}

// Handle Update Fee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_fee'])) {
    $feeID   = (int)$_POST['fee_id'];
    $feeName = trim($_POST['fee_name']);
    $amount  = (float)$_POST['amount'];
    $feeType = $_POST['fee_type'];
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    $stmt = $pdo->prepare("UPDATE fees SET FeeName=?, Amount=?, FeeType=?, IsActive=? WHERE FeeID=?");
    if ($stmt->execute([$feeName, $amount, $feeType, $isActive, $feeID])) {
        $_SESSION['success'] = "Fee updated successfully!";
    }
    header("Location: fees.php");
    exit();
}
?>

<h2>💰 Manage Fees</h2>
<?php displayMessage(); ?>

<!-- Add New Fee Form -->
<h3>Add New Fee</h3>
<form method="POST">
    <input type="text" name="fee_name" placeholder="Fee Name (e.g. Tuition Fee - BSIT)" required style="width:350px;">
    <input type="number" name="amount" placeholder="Amount" step="0.01" required>
    <select name="fee_type" required>
        <option value="Tuition">Tuition</option>
        <option value="Miscellaneous">Miscellaneous</option>
        <option value="Lab">Lab</option>
        <option value="Other">Other</option>
    </select>
    <button type="submit" name="add_fee">Add Fee</button>
</form>

<hr>

<!-- Fees List -->
<h3>Existing Fees</h3>
<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>Fee Name</th>
        <th>Amount</th>
        <th>Type</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <?php
    $stmt = $pdo->query("SELECT * FROM fees ORDER BY FeeName");
    while ($fee = $stmt->fetch()) {
        $status = $fee['IsActive'] ? 'Active' : 'Inactive';
        $color  = $fee['IsActive'] ? 'green' : 'orange';
    ?>
    <tr>
        <td><?= htmlspecialchars($fee['FeeName']) ?></td>
        <td>₱<?= number_format($fee['Amount'], 2) ?></td>
        <td><?= $fee['FeeType'] ?></td>
        <td style="color:<?= $color ?>; font-weight:bold;"><?= $status ?></td>
        <td>
            <button onclick="editFee(<?= $fee['FeeID'] ?>, '<?= htmlspecialchars($fee['FeeName']) ?>', <?= $fee['Amount'] ?>, '<?= $fee['FeeType'] ?>', <?= $fee['IsActive'] ?>)">
                Edit
            </button>
        </td>
    </tr>
    <?php } ?>
</table>

<!-- Edit Fee Modal (Simple JS) -->
<script>
function editFee(id, name, amount, type, active) {
    let newName = prompt("Fee Name:", name);
    if (newName === null) return;
    
    let newAmount = prompt("Amount:", amount);
    if (newAmount === null) return;
    
    let newType = prompt("Type (Tuition/Miscellaneous/Lab/Other):", type);
    if (newType === null) return;
    
    let isActive = confirm("Keep Active?") ? 1 : 0;

    // Submit via hidden form or use fetch, but for simplicity we'll use form
    const form = document.createElement('form');
    form.method = 'POST';
    form.innerHTML = `
        <input type="hidden" name="fee_id" value="${id}">
        <input type="hidden" name="fee_name" value="${newName}">
        <input type="hidden" name="amount" value="${newAmount}">
        <input type="hidden" name="fee_type" value="${newType}">
        <input type="hidden" name="is_active" value="${isActive}">
        <input type="hidden" name="update_fee" value="1">
    `;
    document.body.appendChild(form);
    form.submit();
}
</script>

<?php include '../includes/footer.php'; ?>