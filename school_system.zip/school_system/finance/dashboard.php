<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/header.php';

$page_title = "Finance Dashboard";
requireFinance();
?>

<h1>Welcome, <?= htmlspecialchars($_SESSION['fullname']) ?> (Finance)</h1>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 30px 0;">
    <?php
    $totalStudents = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $totalBalance = $pdo->query("SELECT SUM(TotalBalance) FROM student_accounts")->fetchColumn();
    $pendingPayments = $pdo->query("SELECT COUNT(*) FROM student_accounts WHERE TotalBalance > 0")->fetchColumn();
    ?>
    <div style="background:white; padding:20px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
        <h3>Total Students</h3>
        <h2><?= number_format($totalStudents) ?></h2>
    </div>
    <div style="background:white; padding:20px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
        <h3>Total Outstanding Balance</h3>
        <h2 style="color:red;">₱<?= number_format($totalBalance, 2) ?></h2>
    </div>
    <div style="background:white; padding:20px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
        <h3>Students with Balance</h3>
        <h2><?= number_format($pendingPayments) ?></h2>
    </div>
</div>

<?php include '../includes/footer.php'; ?>