<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFinance();
include '../includes/finance_header.php'; 
?>

<h2>Student Account Balances</h2>

<table border="1" cellpadding="10">
    <tr>
        <th>Student No.</th>
        <th>Student Name</th>
        <th>Balance</th>
        <th>Action</th>
    </tr>
    <?php
    $stmt = $pdo->query("
        SELECT s.StudentID, s.StudentNumber, u.FirstName, u.LastName, 
               COALESCE(sa.TotalBalance, 0) as Balance
        FROM students s 
        JOIN users u ON s.UserID = u.UserID 
        LEFT JOIN student_accounts sa ON s.StudentID = sa.StudentID
        ORDER BY sa.TotalBalance DESC
    ");
    while ($row = $stmt->fetch()) {
        $color = $row['Balance'] > 0 ? 'red' : 'green';
        echo "<tr>
                <td>{$row['StudentNumber']}</td>
                <td>{$row['FirstName']} {$row['LastName']}</td>
                <td style='color:$color; font-weight:bold;'>₱" . number_format($row['Balance'], 2) . "</td>
                <td><a href='assign_fees.php?student_id={$row['StudentID']}'>Assign Fee</a></td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>