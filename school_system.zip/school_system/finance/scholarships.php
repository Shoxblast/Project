<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFinance();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentID       = (int)$_POST['student_id'];
    $scholarshipName = trim($_POST['scholarship_name']);
    $discountAmount  = (float)$_POST['discount_amount'];
    $discountPercent = (float)$_POST['discount_percent'];
    $academicYearID  = (int)$_POST['academic_year_id'];

    $stmt = $pdo->prepare("
        INSERT INTO scholarships 
        (StudentID, ScholarshipName, DiscountAmount, DiscountPercent, AcademicYearID) 
        VALUES (?, ?, ?, ?, ?)
    ");

    if ($stmt->execute([$studentID, $scholarshipName, $discountAmount, $discountPercent, $academicYearID])) {
        $_SESSION['success'] = "Scholarship applied successfully!";
    } else {
        $_SESSION['error'] = "Failed to apply scholarship.";
    }
    header("Location: scholarships.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>🎓 Manage Scholarships</h2>
<?php displayMessage(); ?>

<form method="POST">
    <select name="student_id" required>
        <option value="">Select Student</option>
        <?php
        $students = $pdo->query("
            SELECT s.StudentID, s.StudentNumber, u.FirstName, u.LastName 
            FROM students s 
            JOIN users u ON s.UserID = u.UserID 
            ORDER BY s.StudentNumber
        ")->fetchAll();
        foreach ($students as $s) {
            echo "<option value='{$s['StudentID']}'>{$s['StudentNumber']} - {$s['FirstName']} {$s['LastName']}</option>";
        }
        ?>
    </select><br><br>

    <input type="text" name="scholarship_name" placeholder="Scholarship Name (e.g. Academic Excellence)" required style="width:100%;"><br><br>
    
    <input type="number" name="discount_amount" placeholder="Discount Amount (₱)" step="0.01" style="width:48%;">
    <input type="number" name="discount_percent" placeholder="Discount Percent (%)" step="0.01" max="100" style="width:48%;"><br><br>

    <select name="academic_year_id" required>
        <?php
        $years = $pdo->query("SELECT AcademicYearID, YearName FROM academic_years ORDER BY YearName DESC")->fetchAll();
        foreach ($years as $y) {
            echo "<option value='{$y['AcademicYearID']}'>{$y['YearName']}</option>";
        }
        ?>
    </select><br><br>

    <button type="submit">Apply Scholarship</button>
</form>

<hr>
<h3>Active Scholarships</h3>
<table border="1" cellpadding="10" style="width:100%;">
    <tr>
        <th>Student</th>
        <th>Scholarship</th>
        <th>Discount</th>
        <th>Academic Year</th>
        <th>Status</th>
    </tr>
    <?php
    $stmt = $pdo->query("
        SELECT sch.*, s.StudentNumber, CONCAT(u.FirstName,' ',u.LastName) as StudentName, ay.YearName
        FROM scholarships sch
        JOIN students s ON sch.StudentID = s.StudentID
        JOIN users u ON s.UserID = u.UserID
        LEFT JOIN academic_years ay ON sch.AcademicYearID = ay.AcademicYearID
        WHERE sch.IsActive = 1
        ORDER BY sch.ScholarshipID DESC
    ");
    while ($row = $stmt->fetch()) {
        $discount = $row['DiscountAmount'] > 0 
            ? '₱' . number_format($row['DiscountAmount'], 2) 
            : $row['DiscountPercent'] . '%';
        echo "<tr>
                <td>{$row['StudentNumber']} - {$row['StudentName']}</td>
                <td>{$row['ScholarshipName']}</td>
                <td>{$discount}</td>
                <td>{$row['YearName']}</td>
                <td>Active</td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>