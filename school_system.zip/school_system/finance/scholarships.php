<?php 
require_once '../config/db.php';
require_once '../includes/session.php';
requireFinance();

// ====================== DELETE SCHOLARSHIP ======================
if (isset($_GET['delete'])) {
    $scholarshipID = (int)$_GET['delete'];

    $pdo->beginTransaction();
    try {
        // Get scholarship details before deleting
        $stmt = $pdo->prepare("SELECT StudentID, DiscountAmount, DiscountPercent FROM scholarships WHERE ScholarshipID = ?");
        $stmt->execute([$scholarshipID]);
        $sch = $stmt->fetch();

        if ($sch) {
            // Reverse the discount (add back to balance)
            $totalDiscount = $sch['DiscountAmount'];
            if ($sch['DiscountPercent'] > 0) {
                $balStmt = $pdo->prepare("SELECT TotalBalance FROM student_accounts WHERE StudentID = ?");
                $balStmt->execute([$sch['StudentID']]);
                $current = (float)$balStmt->fetchColumn();
                $totalDiscount += $current * ($sch['DiscountPercent'] / 100);
            }

            // Add back the discount to student's balance
            if ($totalDiscount > 0) {
                $pdo->prepare("UPDATE student_accounts SET TotalBalance = TotalBalance + ? WHERE StudentID = ?")
                     ->execute([$totalDiscount, $sch['StudentID']]);
            }

            // Delete the scholarship record
            $pdo->prepare("DELETE FROM scholarships WHERE ScholarshipID = ?")->execute([$scholarshipID]);

            $pdo->commit();
            $_SESSION['success'] = "✅ Scholarship deleted and balance restored.";
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to delete scholarship.";
    }

    header("Location: scholarships.php");
    exit();
}

// ====================== APPLY NEW SCHOLARSHIP ======================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentID       = (int)$_POST['student_id'];
    $scholarshipName = trim($_POST['scholarship_name']);
    $discountAmount  = (float)$_POST['discount_amount'];
    $discountPercent = (float)$_POST['discount_percent'];
    $academicYearID  = (int)$_POST['academic_year_id'];

    if ($studentID && $scholarshipName) {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("
                INSERT INTO scholarships 
                (StudentID, ScholarshipName, DiscountAmount, DiscountPercent, AcademicYearID, AppliedBy) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$studentID, $scholarshipName, $discountAmount, $discountPercent, $academicYearID, $_SESSION['user_id']]);

            $totalDiscount = 0;

            if ($discountAmount > 0) {
                $totalDiscount += $discountAmount;
            }
            if ($discountPercent > 0) {
                $bal = $pdo->prepare("SELECT TotalBalance FROM student_accounts WHERE StudentID = ?");
                $bal->execute([$studentID]);
                $currentBalance = (float)$bal->fetchColumn();
                $totalDiscount += $currentBalance * ($discountPercent / 100);
            }

            if ($totalDiscount > 0) {
                $pdo->prepare("UPDATE student_accounts SET TotalBalance = TotalBalance - ? WHERE StudentID = ?")
                     ->execute([$totalDiscount, $studentID]);
            }

            $pdo->commit();
            $_SESSION['success'] = "✅ Scholarship applied! Total Discount: ₱" . number_format($totalDiscount, 2);

        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['error'] = "Failed to apply scholarship.";
        }
    }
    header("Location: scholarships.php");
    exit();
}

include '../includes/header.php'; 
?>

<h2>🎓 Manage Scholarships</h2>
<?php displayMessage(); ?>

<!-- Apply New Scholarship Form -->
<form method="POST" style="background:#f8fafc; padding:25px; border-radius:10px; margin-bottom:30px;">
    <label><strong>Select Student</strong></label><br>
    <select name="student_id" required style="width:100%; padding:12px; margin-bottom:15px;">
        <option value="">-- Select Student --</option>
        <?php
        $students = $pdo->query("
            SELECT s.StudentID, s.StudentNumber, u.FirstName, u.LastName, 
                   COALESCE(sa.TotalBalance, 0) as Balance
            FROM students s 
            JOIN users u ON s.UserID = u.UserID 
            LEFT JOIN student_accounts sa ON s.StudentID = sa.StudentID
            ORDER BY s.StudentNumber
        ")->fetchAll();

        foreach ($students as $s) {
            echo "<option value='{$s['StudentID']}'>
                    {$s['StudentNumber']} - {$s['FirstName']} {$s['LastName']} 
                    (₱" . number_format($s['Balance'], 2) . ")
                  </option>";
        }
        ?>
    </select>

    <label><strong>Scholarship Name</strong></label><br>
    <input type="text" name="scholarship_name" placeholder="e.g. Academic Excellence" required style="width:100%; padding:12px; margin-bottom:15px;">

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
        <div>
            <label>Flat Discount (₱)</label><br>
            <input type="number" name="discount_amount" step="0.01" value="0" style="width:100%; padding:12px;">
        </div>
        <div>
            <label>Percentage Discount (%)</label><br>
            <input type="number" name="discount_percent" step="0.01" max="100" value="0" style="width:100%; padding:12px;">
        </div>
    </div>

    <label><strong>Academic Year</strong></label><br>
    <select name="academic_year_id" required style="width:100%; padding:12px; margin:15px 0;">
        <?php
        $years = $pdo->query("SELECT AcademicYearID, YearName FROM academic_years ORDER BY YearName DESC")->fetchAll();
        foreach ($years as $y) {
            echo "<option value='{$y['AcademicYearID']}'>{$y['YearName']}</option>";
        }
        ?>
    </select>

    <button type="submit" style="padding:14px 30px; font-size:16px;">Apply Scholarship</button>
</form>

<!-- Active Scholarships List -->
<h3>Active Scholarships</h3>
<table border="1" cellpadding="12" style="width:100%;">
    <tr>
        <th>Student</th>
        <th>Scholarship</th>
        <th>Discount</th>
        <th>Academic Year</th>
        <th>Action</th>
    </tr>
    <?php
    $stmt = $pdo->query("
        SELECT sch.*, s.StudentNumber, CONCAT(u.FirstName,' ',u.LastName) as StudentName, ay.YearName
        FROM scholarships sch
        JOIN students s ON sch.StudentID = s.StudentID
        JOIN users u ON s.UserID = u.UserID
        LEFT JOIN academic_years ay ON sch.AcademicYearID = ay.AcademicYearID
        WHERE sch.IsActive = 1
        ORDER BY sch.ScholarshipID DESC
    ");
    while ($row = $stmt->fetch()) {
        $discount = '';
        if ($row['DiscountAmount'] > 0) $discount .= '₱' . number_format($row['DiscountAmount'], 2);
        if ($row['DiscountPercent'] > 0) $discount .= ($discount ? ' + ' : '') . $row['DiscountPercent'] . '%';
        
        echo "<tr>
                <td>{$row['StudentNumber']} - {$row['StudentName']}</td>
                <td>{$row['ScholarshipName']}</td>
                <td>{$discount}</td>
                <td>{$row['YearName']}</td>
                <td>
                    <a href='?delete={$row['ScholarshipID']}' 
                       onclick=\"return confirm('Delete this scholarship? This will restore the discount to the student balance.')\"
                       style='color:red;'>Delete</a>
                </td>
              </tr>";
    }
    ?>
</table>

<?php include '../includes/footer.php'; ?>